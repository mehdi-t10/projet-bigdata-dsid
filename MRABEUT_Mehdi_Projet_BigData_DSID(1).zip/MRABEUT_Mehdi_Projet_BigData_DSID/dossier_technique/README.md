# Projet Big Data — M1 MIAGE 2026-2027 (UE DSID)

Chaîne d'ingestion reproductible : **3 sources → RAW (MinIO) → Bronze → Silver (PostgreSQL)**, transformations en **SQL versionné** et **contrôles qualité** automatisés.

Thème : un distributeur de films suit ses **clients exploitants de salles** (CRM), les **films** qu'il programme (API TMDB) et le **parc de cinémas d'Île-de-France** (open data CNC).

| Flux | Source | Chemin |
|---|---|---|
| 1 | **API TMDB** (GET, **authentification Bearer token**, 5 streams) | Airbyte → MinIO `raw/api/tmdb/…` → Airbyte S3 Source → `bronze.tmdb_*` |
| 2 | **CSV** établissements cinématographiques IDF (CNC) | Airbyte File → MinIO `raw/csv/cinemas_idf/…` → Airbyte S3 Source → `bronze.csv_cinemas_idf` |
| 3 | **EspoCRM** (saisies) → MariaDB | Airbyte MySQL Source (lecture seule) → `bronze.crm_*` |
| — | Transformation | `sql/run_all.sql` → schéma `silver` + `silver.dq_results` |

![Architecture](docs/uml/export/01_architecture_composants.png)

## Documentation

| Document | Contenu |
|---|---|
| [docs/01_sources.md](docs/01_sources.md) | description des 3 sources, endpoints, token, colonnes, pièges |
| [docs/02_flux_airbyte.md](docs/02_flux_airbyte.md) | configuration de chaque source/destination/connexion Airbyte |
| [docs/03_transformations.md](docs/03_transformations.md) | règles Bronze → Silver, modèle de données |
| [docs/04_controles.md](docs/04_controles.md) | contrôles qualité (structure, types, unicité, doublons, volumes, traçabilité…) |
| [docs/05_reproductibilite.md](docs/05_reproductibilite.md) | versions, secrets, différences OS, rejeu |
| [docs/06_saisie_crm.md](docs/06_saisie_crm.md) | données à saisir dans EspoCRM + scénario de démonstration |
| [docs/uml/](docs/uml/) | 10 diagrammes UML (sources `.puml` + exports `export/*.png|svg`) |

## Arborescence

```text
.
├── compose.yaml / Dockerfile.minio / .env.example   stack Docker (starter + compte Airbyte PG, montage ./sql)
├── init/postgres/   01_schemas.sql (bronze, silver, unaccent) · 02_airbyte_writer.sh (compte Airbyte limité à bronze)
├── init/mariadb/    01_airbyte_readonly.sh (compte airbyte SELECT only)
├── minio/           policy-airbyte-raw.json (accès limité au bucket dsid-raw)
├── airbyte/connectors/tmdb_manifest.yaml           connecteur low-code TMDB (token en input secret)
├── sql/
│   ├── run_all.sql                                 orchestration (précontrôles → silver → contrôles → rapport)
│   ├── silver/00_functions … 40_conformed.sql      transformations Bronze → Silver
│   ├── tests/00_prechecks_bronze · 10_dq_silver · 99_report
│   └── dev/  generate_fixtures.py + fake_bronze.sql (données FICTIVES de test)
├── scripts/         setup_minio(.sh|.ps1) · run_silver(.sh|.ps1) · test_offline.sh · check_stack.sh · export_uml.sh
├── docs/            documentation + UML
└── rapport/         rapport PDF
```

## Démarrage pas à pas

> Windows : commandes PowerShell équivalentes dans [README_DOCKER.md](README_DOCKER.md) et scripts `.ps1`.

### 1. Stack Docker

```bash
cp .env.example .env          # puis changer TOUS les mots de passe
docker compose build minio
docker compose up -d
docker compose ps             # tous les services "healthy"/"running"
```

**Ports déjà occupés ?** Si un MySQL ou un PostgreSQL local utilise déjà 3306 / 5432, ajouter dans `.env` par exemple `MARIADB_HOST_PORT=3307` et `POSTGRES_HOST_PORT=5433` (valeurs utilisées sur la machine de développement), puis utiliser ces ports dans les connecteurs Airbyte.

Si les volumes existaient **avant** ce dépôt (scripts d'init non joués) :

```bash
# Linux / macOS
docker exec -i dsid-postgres psql -U warehouse -d warehouse < init/postgres/01_schemas.sql
docker exec -i dsid-postgres bash < init/postgres/02_airbyte_writer.sh
docker exec -i dsid-mariadb  bash < init/mariadb/01_airbyte_readonly.sh
docker exec dsid-postgres psql -U warehouse -d warehouse -c "GRANT CREATE ON DATABASE warehouse TO airbyte_writer;"
docker compose up -d postgres   # recrée le conteneur pour monter ./sql sur /sql
```

```powershell
# Windows PowerShell (pas de redirection "<" ; on retire les fins de ligne Windows)
Get-Content init\postgres\01_schemas.sql | docker exec -i dsid-postgres psql -U warehouse -d warehouse
Get-Content init\postgres\02_airbyte_writer.sh | docker exec -i dsid-postgres bash -c "tr -d '\r' | bash"
Get-Content init\mariadb\01_airbyte_readonly.sh | docker exec -i dsid-mariadb bash -c "tr -d '\r' | bash"
docker exec dsid-postgres psql -U warehouse -d warehouse -c "GRANT CREATE ON DATABASE warehouse TO airbyte_writer;"
```

> MariaDB et PostgreSQL conservent les mots de passe de leur **premier** démarrage : si le `.env` a été modifié depuis, utiliser l'ancien mot de passe root ou le réaligner (`ALTER USER warehouse PASSWORD '...'`).

### 2. MinIO (bucket RAW privé + compte Airbyte)

```bash
./scripts/setup_minio.sh      # Windows : scripts\setup_minio.ps1
```

Crée `dsid-raw` (privé), les préfixes `raw/api/tmdb/` et `raw/csv/cinemas_idf/`, et l'utilisateur `MINIO_AIRBYTE_ACCESS_KEY` restreint à ce bucket. Console : http://localhost:9001.

### 3. Airbyte

```bash
curl -LsfS https://get.airbyte.com | bash -
abctl local install
abctl local credentials       # identifiants de http://localhost:8000
```

### 4. Connecteurs et connexions Airbyte

**Méthode automatique (recommandée)** :

1. Airbyte → **Builder → Import a YAML** → `airbyte/connectors/tmdb_manifest.yaml` → **Publish** (nom `TMDB (DSID)`) ;
2. `python scripts/airbyte_setup.py` (Linux sans host.docker.internal : `--host <IP passerelle kind>`).
   Le script demande les identifiants de `abctl local credentials` et le token TMDB (saisie masquée), lit le reste dans `.env`, crée les 3 destinations, 4 sources, 4 connexions et lance les synchros dans l'ordre RAW → Bronze. Idempotent.

**Méthode manuelle** : tout est détaillé champ par champ dans [docs/02_flux_airbyte.md](docs/02_flux_airbyte.md) :

1. **Builder → Import YAML** `airbyte/connectors/tmdb_manifest.yaml` → saisir le **token TMDB** → tester → *Publish* ;
2. destinations **S3 (MinIO)** `raw/api/tmdb` et `raw/csv`, destination **Postgres** `bronze` ;
3. sources **TMDB (DSID)**, **File** (CSV), **S3** (MinIO, 6 streams), **MySQL** (EspoCRM) ;
4. connexions et synchronisations dans l'ordre RAW → Bronze.

Hôte à utiliser dans les connecteurs : `host.docker.internal` (Windows/macOS) ; sous Linux, IP de passerelle kind si nécessaire (`./scripts/check_stack.sh`). **Valeur utilisée pour ce projet : `host.docker.internal` (Windows 11 + Docker Desktop, Airbyte via abctl v0.30.4).**

### 5. Saisie CRM

Suivre [docs/06_saisie_crm.md](docs/06_saisie_crm.md) (comptes, contacts, opportunités), puis synchroniser `espocrm → bronze`.

### 6. Silver + contrôles

```bash
./scripts/run_silver.sh       # Windows : scripts\run_silver.ps1
```

Équivaut à `docker exec -i dsid-postgres psql -U warehouse -d warehouse -v ON_ERROR_STOP=1 -f /sql/run_all.sql`. Affiche la synthèse des contrôles, les KO, les volumes ; code retour `0` = succès, `3` = contrôle bloquant en échec. Journal dans `logs/`.

### 7. Vérifications pour le rapport

```bash
./scripts/check_stack.sh      # docker compose images, abctl version, tables bronze, droits MariaDB…
```

```sql
SELECT * FROM silver.etl_run_log ORDER BY run_id DESC LIMIT 5;
SELECT * FROM silver.v_opportunity_360;
```

## Tester le SQL sans Airbyte

```bash
./scripts/test_offline.sh     # base séparée warehouse_dev + Bronze FICTIF (anomalies volontaires)
```

Exécuté lors du développement : 109 contrôles, 0 bloquant en échec, 5 avertissements correspondant exactement aux anomalies injectées ; run idempotent (relances identiques) ; échec contrôlé si une table Bronze manque ou si une valeur sort de son domaine.

**Exécution réelle (machine de développement Windows, 12/10/2026)** : 111 contrôles, 0 bloquant en échec, run `SUCCESS` — 233 films, 315 cinémas, 6 comptes / 10 contacts / 7 opportunités CRM en Silver (détail dans le rapport PDF).

## URLs locales

Airbyte http://localhost:8000 · EspoCRM http://localhost:8081 · Adminer http://localhost:8082 · MinIO http://localhost:9001 (API :9000) · PostgreSQL localhost:5432 (ou `POSTGRES_HOST_PORT`) · MariaDB localhost:3306 (ou `MARIADB_HOST_PORT`)

## Dépannage

| Symptôme | Cause / solution |
|---|---|
| Airbyte ne joint pas PostgreSQL/MinIO/MariaDB | `localhost` utilisé dans le connecteur → `host.docker.internal` ou IP passerelle kind |
| Source S3 refuse `http://…:9000` | validation HTTPS du connecteur : figer une version testée ou exposer MinIO en HTTPS (docs/02 §2.4) |
| `Précontrôles Bronze en échec : bronze_table_presente / bronze.xxx` | synchronisation Airbyte correspondante non lancée, ou nom de stream différent → adapter `sql/silver/01_staging_views.sql` |
| `/sql/run_all.sql: No such file` | conteneur postgres créé avant l'ajout du montage → `docker compose up -d postgres` |
| Colonnes CSV non reconnues (`cinema_idf` vide) | vérifier les clés : `SELECT DISTINCT jsonb_object_keys(_airbyte_data) FROM bronze.csv_cinemas_idf;` et compléter les alias de `f_pick` |
| Token TMDB refusé (401) | utiliser l'**API Read Access Token** (v4, `eyJ…`), pas la clé API v3 courte |

## Auteur

Mehdi M'RABEUT — M1 MIAGE, Université Paris-Saclay — enseignant : Guilherme ANTUNES.

# Contexte et objectifs

L'objectif est de construire une chaîne d'ingestion **reproductible** qui collecte trois sources hétérogènes, les conserve à l'état brut, les charge dans une couche **Bronze** puis produit, en **SQL versionné dans PostgreSQL**, une couche **Silver** nettoyée, typée, dédoublonnée et contrôlée.

L'architecture a été validée par l'enseignant : trois flux (API publique, CSV, CRM), logique RAW / Bronze / Silver, transformations Bronze → Silver en SQL avec les contrôles vus en TP, et documentation des sources, flux, transformations, contrôles et de la reproductibilité.

**Cas d'usage retenu.** Un distributeur de films suit ses clients exploitants de salles dans un CRM (EspoCRM), s'appuie sur l'API **TMDB** pour connaître les films à l'affiche et leur popularité, et sur le fichier **CNC des établissements cinématographiques d'Île-de-France** pour qualifier ses clients (écrans, fauteuils, entrées). La couche Silver permet de relier les trois : *quelle opportunité, pour quel film, dans quel cinéma ?*

**Choix structurants**

- API **avec authentification** (Bearer token TMDB) saisie comme *input* secret du connecteur, et **plusieurs streams** (5, dont un sous-stream parent → enfant) ;
- transformations **exclusivement en SQL** (Airbyte ne transforme rien) ;
- contrôles qualité historisés, avec sévérité bloquante / avertissement ;
- **UML exporté** (PNG + SVG) pour chaque vue : architecture, déploiement, séquences des 3 flux, modèles Bronze et Silver, activité, cas d'utilisation, lignage.

![Cas d'utilisation](uml/export/09_cas_utilisation.svg)

# Architecture

![Déploiement](uml/export/02_deploiement.svg)

Airbyte (installé par `abctl` dans un cluster *kind*) est isolé du réseau Docker Compose : les connecteurs joignent PostgreSQL, MariaDB et MinIO via `host.docker.internal` (Windows/macOS) ou l'IP de passerelle du nœud kind (Linux).

![Modèle Bronze](uml/export/06_classes_bronze.svg)

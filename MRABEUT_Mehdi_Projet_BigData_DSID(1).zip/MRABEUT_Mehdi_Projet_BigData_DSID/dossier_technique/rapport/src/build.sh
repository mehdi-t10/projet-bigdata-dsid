#!/usr/bin/env bash
# Génère rapport/rapport_projet_big_data.pdf à partir des docs (pandoc + Chromium/Playwright)
set -euo pipefail
cd "$(dirname "$0")"
D=../../docs
pandoc 00_intro.md $D/01_sources.md $D/02_flux_airbyte.md $D/03_transformations.md \
       $D/04_controles.md $D/05_reproductibilite.md $D/06_saisie_crm.md 99_conclusion.md \
  -f markdown -t html5 --standalone --embed-resources --toc --toc-depth=2 \
  --resource-path=$D:. -B cover.html --css style.css \
  --metadata pagetitle="Projet Big Data DSID" --metadata lang=fr -o ../rapport.html
python3 - <<'PY'
from playwright.sync_api import sync_playwright
import pathlib
p = pathlib.Path('../rapport.html').resolve()
with sync_playwright() as pw:
    b = pw.chromium.launch(); pg = b.new_page()
    pg.goto(p.as_uri()); pg.pdf(path=str(p.parent / 'rapport_projet_big_data.pdf'), format='A4',
        print_background=True, display_header_footer=True,
        header_template='<span></span>',
        footer_template='<div style="font-size:8px;width:100%;text-align:center;color:#63003C">Projet Big Data DSID — M1 MIAGE — <span class="pageNumber"></span>/<span class="totalPages"></span></div>',
        margin={'top':'16mm','bottom':'16mm','left':'14mm','right':'14mm'})
    b.close()
PY
rm -f ../rapport.html
echo "OK : rapport/rapport_projet_big_data.pdf"

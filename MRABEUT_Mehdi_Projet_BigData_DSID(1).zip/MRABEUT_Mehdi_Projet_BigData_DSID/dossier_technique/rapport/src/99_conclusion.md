# Résultats d'exécution (machine de développement Windows, 12/10/2026)

Environnement : Windows + Docker Desktop, Airbyte installé par `abctl` (cluster kind), hôte vu depuis Airbyte : `host.docker.internal`.

## Volumes obtenus

| Étape | Résultat |
|---|---|
| API TMDB → MinIO (RAW) | **419** enregistrements (5 streams), fichiers JSONL dans `dsid-raw/raw/api/tmdb/<stream>/` |
| CSV cinémas → MinIO (RAW) | **315** établissements, `dsid-raw/raw/csv/cinemas_idf/` |
| MinIO → bronze | 6 tables `bronze.tmdb_*` + `bronze.csv_cinemas_idf` |
| EspoCRM → bronze | tables `bronze.crm_*` (comptes, contacts, opportunités, e-mails, téléphones) |

| Table Silver | Lignes |
|---|---|
| `tmdb_genre` | 19 |
| `tmdb_film` | 233 |
| `tmdb_film_genre` | 547 |
| `tmdb_film_country` | 173 |
| `tmdb_film_list_snapshot` | 289 |
| `cinema_idf` | 315 |
| `crm_account` | 6 |
| `crm_contact` | 10 |
| `crm_opportunity` | 7 |
| `crm_account_cinema_link` | 2 |

## Contrôles qualité (run n°3)

**111 contrôles exécutés — 0 BLOQUANT en échec — run `SUCCESS`.** Un seul avertissement, attendu : `contact_joignable` (3 contacts sans e-mail ni téléphone : Matteo LORENZO, Sarra MARTIN, Emma ROUX). Le run n°1 avait été mis en `FAILED` par le contrôle bloquant `silver_non_vide` sur `cinema_idf` (en-tête « Nom de l'établissement » non reconnu) : le contrôle a joué son rôle, l'alias a été ajouté au SQL et le run suivant est passé.

Rapprochement CRM ↔ CNC : 2 comptes sur 6 reliés automatiquement (nom normalisé + ville). Les autres noms saisis dans le CRM diffèrent de ceux du fichier CNC ; le champ personnalisé « N° CNC » permettrait un rapprochement exact.

## Versions effectivement utilisées

| Composant | Version |
|---|---|
| PostgreSQL / MariaDB / EspoCRM / Adminer | 18.6 / 11.8.9 / 10.0.8 / 6.1.0 (`compose.yaml`) |
| MinIO | `RELEASE.2025-10-15T17-29-55Z` (build local, Community Edition) |
| Airbyte | Community Edition installée par `abctl` **v0.30.4** |
| Connecteur TMDB (DSID) | `airbyte/source-declarative-manifest:7.28.2` (manifeste low-code du dépôt) |
| Source File (CSV) | `airbyte/source-file:0.6.0` |
| Source S3 (lecture MinIO) | `airbyte/source-s3:4.15.25` — endpoint `http://` accepté |
| Source MySQL (EspoCRM) | `airbyte/source-mysql:3.53.5` |
| Destination S3 (MinIO) | `airbyte/destination-s3:1.9.9` |
| Destination Postgres | `airbyte/destination-postgres:3.0.22` |

### Sorties demandées (README_DOCKER, règle 10)

`docker compose images` :

```text
CONTAINER             REPOSITORY          TAG                            PLATFORM            IMAGE ID            SIZE                CREATED
dsid-adminer          adminer             6.1.0                          linux/amd64         8df93d7bb431        164MB               6 weeks ago
dsid-espocrm          espocrm/espocrm     10.0.8                         linux/amd64         817f2b063de2        1.08GB              2 months ago
dsid-espocrm-daemon   espocrm/espocrm     10.0.8                         linux/amd64         817f2b063de2        1.08GB              2 months ago
dsid-mariadb          mariadb             11.8.9                         linux/amd64         79d59758afc9        453MB               8 weeks ago
dsid-minio            dsid/minio          RELEASE.2025-10-15T17-29-55Z   linux/amd64         b0165de3ea96        233MB               6 weeks ago
dsid-postgres         postgres            18.6                           linux/amd64         5a5a84b19854        644MB               7 weeks ago
```

`abctl version` :

```text
version: v0.30.4
```

Ports hôte retenus sur la machine de développement : PostgreSQL **5433**, MariaDB **3307** (ports par défaut déjà occupés par des SGBD locaux).

# Preuves d'exécution (captures)

![Les 4 connexions Airbyte, toutes « healthy »](../captures/01_airbyte_connexions.jpg)

![Connecteur TMDB (Builder) : le token est un input secret masqué, avec langue, région et nombre de pages](../captures/06_builder_inputs_token.jpg)

![Test du stream `genres` dans le Builder : 19 enregistrements renvoyés par l'API authentifiée](../captures/05_builder_tmdb_test.jpg)

![Flux 1 : API TMDB → MinIO (5 streams synchronisés)](../captures/02_tmdb_vers_minio.jpg)

![RAW MinIO : bucket privé `dsid-raw`, un préfixe par stream sous `raw/api/tmdb/`](../captures/07_minio_raw_api.jpg)

![RAW MinIO : fichier JSONL horodaté produit par la synchronisation](../captures/08_minio_fichier_jsonl.jpg)

![RAW MinIO : CSV cinémas sous `raw/csv/cinemas_idf/`](../captures/09_minio_raw_csv.jpg)

![Flux 1 et 2 : MinIO → PostgreSQL bronze (315 cinémas, 19 genres, 4 × 100 films)](../captures/03_minio_vers_bronze.jpg)

![Flux 3 : EspoCRM (MariaDB) → PostgreSQL bronze](../captures/04_espocrm_vers_bronze.jpg)

![EspoCRM : comptes (cinémas clients) saisis](../captures/10_espocrm_comptes.jpg)

![EspoCRM : contacts saisis](../captures/11_espocrm_contacts.jpg)

![EspoCRM : opportunités saisies](../captures/12_espocrm_opportunites.jpg)

![Construction Silver + contrôles : sortie de `scripts\run_silver.ps1` (run n°3, retranscrite du journal `logs/run_silver_20261012_162128.log`)](../captures/13_run_silver_powershell.png){width=78%}

## Problèmes rencontrés et solutions (retour d'expérience)

| Problème | Cause | Solution retenue |
|---|---|---|
| Destination S3 : « Access Key Id does not exist » | la console MinIO communautaire récente ne gère plus les utilisateurs ; le compte de service n'avait pas été créé | compte root MinIO utilisé pour Airbyte (`scripts/setup_minio.*` crée un compte dédié via `mc` quand c'est possible) |
| Source MySQL : accès refusé / port occupé | un MySQL local occupait déjà le port 3306 de la machine | port hôte paramétrable : `MARIADB_HOST_PORT=3307` |
| Destination Postgres : délai dépassé | un PostgreSQL local occupait 5432 | `POSTGRES_HOST_PORT=5433` |
| Destination Postgres : `permission denied for database` | Airbyte crée ses schémas internes | `GRANT CREATE ON DATABASE warehouse TO airbyte_writer` |
| Synchro MinIO → bronze : `column "_airbyte_raw_id" specified more than once` | les fichiers RAW contiennent déjà les colonnes techniques Airbyte de la 1re synchro | sélection de colonnes dans la connexion : `_airbyte_data`, `_ab_source_file_url`, `_ab_source_file_last_modified` |
| Scripts d'init non joués | volumes MariaDB/PostgreSQL créés avant le projet (les scripts `docker-entrypoint-initdb.d` ne s'exécutent qu'au 1er démarrage) | exécution manuelle documentée (README), en retirant les fins de ligne Windows (`tr -d '\r'`) |
| Mot de passe root MariaDB différent du `.env` | MariaDB conserve le mot de passe du premier démarrage | utilisation du mot de passe d'origine pour créer le compte `airbyte` |

# Limites et améliorations

- **Source S3 / MinIO en HTTP** : dans notre installation, l'endpoint `http://host.docker.internal:9000` a été accepté ; la version du connecteur utilisée doit être relevée et figée.
- **Moindre privilège MinIO** : Airbyte utilise le compte root MinIO (console communautaire sans gestion des utilisateurs) ; en production, créer un compte de service limité au bucket via `mc admin`.
- **Suppressions CRM** : la synchro incrémentale par curseur `modified_at` ne capte pas toujours les suppressions logiques ; le CDC (binlog MariaDB) serait la solution complète.
- **Rapprochement compte ↔ cinéma** par nom : fiabilisé par le champ personnalisé N° CNC ; sans lui, confiance 0,5 à 0,8.
- **Données TMDB** : popularité calculée par TMDB, non comparable aux entrées réelles ; l'historique `tmdb_film_list_snapshot` ne se remplit qu'avec des extractions régulières (planification Airbyte quotidienne recommandée).
- **Suite naturelle** : couche **Gold** (indicateurs : CA pondéré par film, taux de transformation par cinéma, part Art et Essai du portefeuille), orchestration planifiée et tests dans une CI.

# Annexe — fichiers livrés

| Dossier | Contenu |
|---|---|
| `compose.yaml`, `.env.example`, `init/` | stack et comptes à moindre privilège |
| `airbyte/connectors/tmdb_manifest.yaml` | connecteur TMDB (token en input secret, 5 streams) |
| `scripts/` | MinIO, exécution Silver, tests hors ligne, vérifications, export UML (Linux/macOS + PowerShell) |
| `sql/silver/`, `sql/tests/`, `sql/run_all.sql` | transformations et contrôles |
| `docs/` + `docs/uml/` | documentation et 10 diagrammes UML (`.puml`, `.png`, `.svg`) |

# scripts/check_stack.ps1 — Vérifications + versions à copier dans le rapport (Windows)
Set-Location (Join-Path $PSScriptRoot "..")
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Get-Content .env | Where-Object { $_ -match '^\s*[A-Z_]+=' } | ForEach-Object { $k, $v = $_ -split '=', 2; Set-Item -Path "Env:$($k.Trim())" -Value $v.Trim() }
Write-Host "== docker compose images"; docker compose images
Write-Host "== docker compose ps";     docker compose ps
Write-Host "== abctl version";         abctl version
Write-Host "== Tables bronze (lignes)"
docker exec dsid-postgres psql -U $env:POSTGRES_USER -d $env:POSTGRES_DB -c "SELECT relname AS table_bronze, n_live_tup AS lignes FROM pg_stat_user_tables WHERE schemaname='bronze' ORDER BY 1"
Write-Host "== Derniers runs Silver"
docker exec dsid-postgres psql -U $env:POSTGRES_USER -d $env:POSTGRES_DB -c "SELECT run_id, status, started_at, finished_at FROM silver.etl_run_log ORDER BY run_id DESC LIMIT 5"
Write-Host "== Droits MariaDB du compte airbyte"
docker exec dsid-mariadb mariadb -uroot -p"$env:MARIADB_ROOT_PASSWORD" -e "SHOW GRANTS FOR 'airbyte'@'%'"

#!/usr/bin/env bash
# =====================================================================
# scripts/test_offline.sh — Teste TOUT le SQL Silver + contrôles SANS Airbyte,
# sur une base SÉPARÉE "warehouse_dev" alimentée par des données FICTIVES
# (sql/dev/fake_bronze.sql). La base "warehouse" n'est jamais touchée.
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./.env; set +a
PSQL="docker exec -i dsid-postgres psql -U $POSTGRES_USER"

$PSQL -d postgres -qc "DROP DATABASE IF EXISTS warehouse_dev" -c "CREATE DATABASE warehouse_dev"
$PSQL -d warehouse_dev -q -v ON_ERROR_STOP=1 < init/postgres/01_schemas.sql
$PSQL -d warehouse_dev -q -v ON_ERROR_STOP=1 < sql/dev/fake_bronze.sql
$PSQL -d warehouse_dev -v ON_ERROR_STOP=1 -f /sql/run_all.sql
echo "OK : pipeline Silver validé sur données fictives (base warehouse_dev)."

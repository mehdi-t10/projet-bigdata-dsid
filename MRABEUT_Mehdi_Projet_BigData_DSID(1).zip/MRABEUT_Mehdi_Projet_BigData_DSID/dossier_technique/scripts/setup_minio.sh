#!/usr/bin/env bash
# =====================================================================
# scripts/setup_minio.sh  (Linux / macOS / Git Bash sous Windows)
# Crée dans MinIO :
#   - le bucket PRIVÉ dsid-raw
#   - les préfixes raw/api/tmdb/ et raw/csv/cinemas_idf/
#   - un utilisateur dédié Airbyte limité à ce bucket (policy minio/policy-airbyte-raw.json)
# Utilise le client mc dans un conteneur éphémère branché sur le réseau Compose.
# Idempotent : peut être relancé sans erreur.
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f .env ] || { echo "Fichier .env absent (cp .env.example .env)"; exit 1; }
set -a; . ./.env; set +a

MC_IMAGE="${MC_IMAGE:-minio/mc:latest}"   # figez un tag RELEASE.* et notez-le dans le rapport
NET="dsid-bigdata-network"
BUCKET="${MINIO_BUCKET:-dsid-raw}"

mc() {
  docker run --rm --network "$NET" \
    -v "$PWD/minio:/policies:ro" \
    -e MC_HOST_local="http://${MINIO_ROOT_USER}:${MINIO_ROOT_PASSWORD}@minio:9000" \
    "$MC_IMAGE" "$@"
}

echo "== Bucket ${BUCKET}"
mc mb --ignore-existing "local/${BUCKET}"
mc anonymous set none "local/${BUCKET}"           # bucket privé

echo "== Préfixes (objets marqueurs .keep)"
for p in raw/api/tmdb raw/csv/cinemas_idf; do
  echo "prefix ${p}" | docker run --rm -i --network "$NET" \
    -e MC_HOST_local="http://${MINIO_ROOT_USER}:${MINIO_ROOT_PASSWORD}@minio:9000" \
    "$MC_IMAGE" pipe "local/${BUCKET}/${p}/.keep"
done

echo "== Utilisateur Airbyte + policy limitée au bucket"
mc admin user add local "${MINIO_AIRBYTE_ACCESS_KEY}" "${MINIO_AIRBYTE_SECRET_KEY}"
mc admin policy create local airbyte-raw-rw /policies/policy-airbyte-raw.json 2>/dev/null \
  || echo "(policy déjà existante)"
mc admin policy attach local airbyte-raw-rw --user "${MINIO_AIRBYTE_ACCESS_KEY}" 2>/dev/null \
  || echo "(policy déjà attachée)"

echo "== Contenu"
mc ls --recursive "local/${BUCKET}"
echo "OK : bucket ${BUCKET} prêt. Clés Airbyte = MINIO_AIRBYTE_ACCESS_KEY / MINIO_AIRBYTE_SECRET_KEY du .env"

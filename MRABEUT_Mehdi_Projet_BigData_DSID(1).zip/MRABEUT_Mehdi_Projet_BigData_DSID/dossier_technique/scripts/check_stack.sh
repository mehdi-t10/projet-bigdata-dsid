#!/usr/bin/env bash
# =====================================================================
# scripts/check_stack.sh — Vérifications de reproductibilité + versions
# (sorties à copier dans le rapport PDF)
# =====================================================================
cd "$(dirname "$0")/.."
set -a; . ./.env; set +a
echo "== docker compose images";  docker compose images
echo "== docker compose ps";      docker compose ps
echo "== abctl version";          abctl version 2>/dev/null || echo "abctl non trouvé"
echo "== PostgreSQL : schémas"
docker exec dsid-postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Atc \
  "SELECT schema_name FROM information_schema.schemata WHERE schema_name IN ('bronze','silver','airbyte_internal') ORDER BY 1"
echo "== PostgreSQL : tables bronze (lignes)"
docker exec dsid-postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c \
  "SELECT relname AS table_bronze, n_live_tup AS lignes FROM pg_stat_user_tables WHERE schemaname='bronze' ORDER BY 1"
echo "== MariaDB : droits du compte airbyte (doit être SELECT uniquement sur espocrm)"
docker exec dsid-mariadb mariadb -uroot -p"$MARIADB_ROOT_PASSWORD" -e "SHOW GRANTS FOR 'airbyte'@'%'"
echo "== Passerelle Docker du nœud kind Airbyte (hôte à utiliser sous Linux si host.docker.internal échoue)"
NODE=$(docker ps --filter name=airbyte-abctl-control-plane --format '{{.Names}}' | head -n 1)
[ -n "$NODE" ] && docker inspect "$NODE" --format '{{range .NetworkSettings.Networks}}{{.Gateway}}{{end}}' || echo "Airbyte non démarré"

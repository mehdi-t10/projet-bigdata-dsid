#!/usr/bin/env bash
# =====================================================================
# scripts/run_silver.sh — Construit Silver + exécute les contrôles (Linux/macOS/Git Bash)
# À lancer APRÈS les synchronisations Airbyte (bronze rempli).
# Le résultat est aussi archivé dans logs/run_silver_<date>.log
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./.env; set +a
mkdir -p logs
LOG="logs/run_silver_$(date +%Y%m%d_%H%M%S).log"
GITV=$(git rev-parse --short HEAD 2>/dev/null || echo "hors-git")

set +e
docker exec -i dsid-postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" \
  -v ON_ERROR_STOP=1 -v git_version="$GITV" -f /sql/run_all.sql 2>&1 | tee "$LOG"
rc=${PIPESTATUS[0]}
echo "Journal : $LOG (code retour $rc)"
exit $rc

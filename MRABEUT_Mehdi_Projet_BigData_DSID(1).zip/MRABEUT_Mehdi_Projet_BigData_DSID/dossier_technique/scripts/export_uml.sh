#!/usr/bin/env bash
# =====================================================================
# scripts/export_uml.sh — Régénère les exports PNG + SVG des diagrammes UML
# Prérequis : Java + plantuml.jar (https://plantuml.com/download)
#   PLANTUML_JAR=/chemin/plantuml.jar ./scripts/export_uml.sh
# Alternative sans Java : extension VS Code "PlantUML" ou https://www.plantuml.com/plantuml
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")/../docs/uml"
JAR="${PLANTUML_JAR:-plantuml.jar}"
for fmt in png svg; do
  java -Djava.awt.headless=true -jar "$JAR" -charset UTF-8 -t"$fmt" -o export ./*.puml
done
ls -1 export

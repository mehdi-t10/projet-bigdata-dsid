#!/usr/bin/env python3
"""
scripts/airbyte_setup.py — Configure TOUT Airbyte automatiquement via son API
(sources, destinations, connexions, synchronisations) pour les 3 flux du projet.

Prérequis
  1. Stack démarrée (docker compose up -d) + scripts/setup_minio.sh exécuté
  2. Airbyte installé (abctl local install)
  3. Connecteur TMDB importé UNE fois dans le Builder et publié sous le nom
     "TMDB (DSID)" (Builder > Import a YAML > airbyte/connectors/tmdb_manifest.yaml > Publish)
  4. Identifiants API Airbyte : `abctl local credentials` affiche Client-Id et Client-Secret

Usage (depuis la racine du projet, Python 3.8+, aucune dépendance) :
  python scripts/airbyte_setup.py              # tout : RAW puis Bronze, avec synchros
  python scripts/airbyte_setup.py --no-sync    # crée seulement la configuration
  python scripts/airbyte_setup.py --host 172.18.0.1   # Linux si host.docker.internal échoue

Les secrets sont lus dans .env ; le token TMDB et les identifiants Airbyte sont
demandés au clavier (jamais écrits sur disque). Script idempotent : un objet déjà
existant (même nom) est réutilisé.
"""
import argparse, getpass, json, os, sys, time, urllib.error, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
API = "http://localhost:8000/api/public/v1"
API_INT = "http://localhost:8000/api/v1"
TOKEN = None

CSV_URL = ("https://data.iledefrance.fr/api/explore/v2.1/catalog/datasets/"
           "salle_de_cinema_ile-de-france/exports/csv?use_labels=true")
TMDB_STREAMS = ["genres", "movies_now_playing", "movies_popular", "trending_week", "movie_details"]
S3_PATH_FORMAT = "${STREAM_NAME}/${YEAR}_${MONTH}_${DAY}_${EPOCH}_"


# ------------------------------------------------------------------ utilitaires
def load_env():
    env = {}
    path = os.path.join(ROOT, ".env")
    if not os.path.exists(path):
        sys.exit("Fichier .env absent : cp .env.example .env")
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env


def call(method, url, body=None, auth=True):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    if auth and TOKEN:
        req.add_header("Authorization", "Bearer " + TOKEN)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            txt = r.read().decode()
            return json.loads(txt) if txt else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")
        raise RuntimeError(f"{method} {url} -> HTTP {e.code}\n{detail[:1500]}") from None


def step(msg):
    print(f"\n=== {msg}")


def find_by_name(kind, ws, name):
    """kind = sources | destinations | connections"""
    res = call("GET", f"{API}/{kind}?workspaceIds={ws}&limit=100")
    for item in res.get("data", []):
        if item.get("name") == name:
            return item
    return None


def ensure(kind, ws, name, payload, id_key):
    existing = find_by_name(kind, ws, name)
    if existing:
        print(f"  = {name} existe déjà ({existing[id_key]})")
        return existing[id_key]
    payload = dict(payload, name=name, workspaceId=ws) if kind != "connections" else dict(payload, name=name)
    created = call("POST", f"{API}/{kind}", payload)
    print(f"  + {name} créé ({created[id_key]})")
    return created[id_key]


AUTH = {}


def authenticate():
    global TOKEN
    TOKEN = call("POST", f"{API}/applications/token",
                 {"client_id": AUTH["id"], "client_secret": AUTH["secret"], "grant-type": "client_credentials"},
                 auth=False)["access_token"]


def safe_call(method, url, body=None, tries=30):
    """Appel tolérant : Airbyte coupe parfois la connexion pendant une synchro
    (machine chargée) ou le jeton expire (~3 min) -> on attend et on réessaie."""
    for i in range(tries):
        try:
            return call(method, url, body)
        except RuntimeError as e:
            if "HTTP 401" in str(e) or "HTTP 403" in str(e):
                authenticate()
            elif "HTTP 5" not in str(e):
                raise
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(15)
        try:
            authenticate()
        except Exception:
            pass
    raise RuntimeError(f"Airbyte ne répond plus ({url}). Vérifiez http://localhost:8000 et la mémoire Docker.")


def running_job(conn_id):
    try:
        res = safe_call("GET", f"{API}/jobs?connectionId={conn_id}&limit=20")
    except RuntimeError:
        return None          # liste des jobs indisponible : on lancera une nouvelle synchro
    for j in res.get("data", []):
        if j.get("status") in ("pending", "running"):
            return j["jobId"]
    return None


def sync(conn_id, label):
    jid = running_job(conn_id)
    if jid:
        print(f"  > synchro {label} déjà en cours (job {jid}), on attend", end="", flush=True)
    else:
        try:
            jid = safe_call("POST", f"{API}/jobs", {"connectionId": conn_id, "jobType": "sync"})["jobId"]
        except RuntimeError as e:
            if "409" not in str(e):
                raise
            jid = running_job(conn_id)
        print(f"  > synchro {label} lancée (job {jid})", end="", flush=True)
    while True:
        time.sleep(15)
        st = safe_call("GET", f"{API}/jobs/{jid}")
        status = st.get("status")
        print(".", end="", flush=True)
        if status in ("succeeded", "failed", "cancelled", "incomplete"):
            print(f" {status.upper()} ({st.get('rowsSynced', '?')} lignes)")
            if status != "succeeded":
                print(f"    -> voir les logs : http://localhost:8000 > Connections > {label}")
            return status == "succeeded"


# ------------------------------------------------------------------ programme
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="host.docker.internal",
                    help="hôte de la machine vu depuis Airbyte (défaut host.docker.internal)")
    ap.add_argument("--no-sync", action="store_true")
    ap.add_argument("--skip-raw", action="store_true", help="ne relance pas les synchros RAW (déjà réussies)")
    ap.add_argument("--max-pages", type=int, default=5)
    args = ap.parse_args()
    env = load_env()
    H = args.host

    step("Authentification Airbyte (valeurs de `abctl local credentials`)")
    cid = os.environ.get("AIRBYTE_CLIENT_ID") or input("  Client-Id     : ").strip()
    csec = os.environ.get("AIRBYTE_CLIENT_SECRET") or getpass.getpass("  Client-Secret : ").strip()
    AUTH.update(id=cid, secret=csec)
    authenticate()
    ws = call("GET", f"{API}/workspaces")["data"][0]["workspaceId"]
    print(f"  OK, workspace {ws}")

    step("Connecteur TMDB (DSID) publié dans le Builder")
    defs = call("POST", f"{API_INT}/source_definitions/list_for_workspace", {"workspaceId": ws})
    all_defs = defs.get("sourceDefinitions", [])
    # On veut NOTRE connecteur publié depuis le Builder ("TMDB (DSID)"),
    # pas le connecteur "TMDb" du catalogue Airbyte (autre schéma de config).
    tmdb_def = (next((d for d in all_defs if d.get("sourceDefinitionId") == os.environ.get("TMDB_DEF_ID")), None)
                or next((d for d in all_defs if "dsid" in d.get("name", "").lower()), None)
                or next((d for d in all_defs if "tmdb" in d.get("name", "").lower()
                         and (d.get("custom") or d.get("releaseStage") == "custom"
                              or "declarative" in str(d.get("dockerRepository", "")).lower())), None))
    if not tmdb_def:
        sys.exit("  Connecteur introuvable : Builder > Import a YAML > "
                 "airbyte/connectors/tmdb_manifest.yaml > Publish (nom 'TMDB (DSID)'), puis relancer.")
    print(f"  OK : {tmdb_def['name']} ({tmdb_def['sourceDefinitionId']})")

    tmdb_token = os.environ.get("TMDB_TOKEN") or getpass.getpass(
        "  Token TMDB (API Read Access Token, eyJ...) : ").strip()

    minio_key, minio_secret = env["MINIO_AIRBYTE_ACCESS_KEY"], env["MINIO_AIRBYTE_SECRET_KEY"]
    bucket = env.get("MINIO_BUCKET", "dsid-raw")
    pg_user = env.get("AIRBYTE_PG_USER", "airbyte_writer")
    pg_pwd = env.get("AIRBYTE_PG_PASSWORD") or env["POSTGRES_PASSWORD"]

    # ---------------- destinations
    step("Destinations")

    def s3_dest(path):
        return {"configuration": {
            "destinationType": "s3",
            "s3_bucket_name": bucket, "s3_bucket_path": path, "s3_bucket_region": "us-east-1",
            "access_key_id": minio_key, "secret_access_key": minio_secret,
            "s3_endpoint": f"http://{H}:9000", "s3_path_format": S3_PATH_FORMAT,
            "format": {"format_type": "JSONL", "flattening": "No flattening",
                       "compression": {"compression_type": "No Compression"}}}}

    d_raw_api = ensure("destinations", ws, "minio_raw_api", s3_dest("raw/api/tmdb"), "destinationId")
    d_raw_csv = ensure("destinations", ws, "minio_raw_csv", s3_dest("raw/csv"), "destinationId")
    d_bronze = ensure("destinations", ws, "postgres_bronze", {"configuration": {
        "destinationType": "postgres", "host": H, "port": int(env.get("POSTGRES_HOST_PORT", 5432)), "database": env["POSTGRES_DB"],
        "schema": "bronze", "username": pg_user, "password": pg_pwd,
        "ssl_mode": {"mode": "disable"}, "tunnel_method": {"tunnel_method": "NO_TUNNEL"}}},
        "destinationId")

    # ---------------- sources flux 1 & 2 (RAW)
    step("Sources API TMDB et CSV")
    s_tmdb = ensure("sources", ws, "tmdb_api", {
        "definitionId": tmdb_def["sourceDefinitionId"],
        "configuration": {"api_token": tmdb_token, "language": "fr-FR", "region": "FR",
                          "max_pages": args.max_pages}}, "sourceId")
    s_csv = ensure("sources", ws, "csv_cinemas_idf", {"configuration": {
        "sourceType": "file", "dataset_name": "cinemas_idf", "format": "csv", "url": CSV_URL,
        "provider": {"storage": "HTTPS", "user_agent": False},
        "reader_options": json.dumps({"sep": ";", "encoding": "utf-8"})}}, "sourceId")

    step("Connexions RAW (API/CSV -> MinIO)")
    c_tmdb_raw = ensure("connections", ws, "tmdb -> minio_raw", {
        "sourceId": s_tmdb, "destinationId": d_raw_api, "schedule": {"scheduleType": "manual"},
        "configurations": {"streams": [{"name": s, "syncMode": "full_refresh_append"} for s in TMDB_STREAMS]}},
        "connectionId")
    c_csv_raw = ensure("connections", ws, "csv_cinemas -> minio_raw", {
        "sourceId": s_csv, "destinationId": d_raw_csv, "schedule": {"scheduleType": "manual"},
        "configurations": {"streams": [{"name": "cinemas_idf", "syncMode": "full_refresh_append"}]}},
        "connectionId")

    if not args.no_sync and not args.skip_raw:
        step("Synchronisations RAW")
        ok1 = sync(c_tmdb_raw, "tmdb -> minio_raw")
        ok2 = sync(c_csv_raw, "csv_cinemas -> minio_raw")
        if not (ok1 and ok2):
            sys.exit("Synchro RAW en échec : corriger puis relancer le script (idempotent).")

    # ---------------- source S3 (MinIO) -> bronze
    step("Source S3 (lecture MinIO) -> bronze")
    s3_streams = [{"name": f"tmdb_{s}", "globs": [f"raw/api/tmdb/{s}/**/*.jsonl"]} for s in TMDB_STREAMS]
    s3_streams.append({"name": "csv_cinemas_idf", "globs": ["raw/csv/cinemas_idf/**/*.jsonl"]})
    for st in s3_streams:
        st.update({"format": {"filetype": "jsonl"}, "validation_policy": "Emit Record",
                   "days_to_sync_if_history_is_full": 3})
    s_minio = ensure("sources", ws, "minio_raw_reader", {"configuration": {
        "sourceType": "s3", "bucket": bucket, "endpoint": f"http://{H}:9000",
        "aws_access_key_id": minio_key, "aws_secret_access_key": minio_secret,
        "streams": s3_streams}}, "sourceId")
    c_raw_bronze = ensure("connections", ws, "minio_raw -> bronze", {
        "sourceId": s_minio, "destinationId": d_bronze, "schedule": {"scheduleType": "manual"},
        "namespaceDefinition": "destination",
        # Sélection de colonnes : les fichiers RAW contiennent déjà des colonnes _airbyte_*
        # (ajoutées par la destination S3) qui entrent en collision avec celles de la
        # destination Postgres ("column _airbyte_raw_id specified more than once").
        # On ne garde que la donnée métier + la traçabilité fichier.
        "configurations": {"streams": [{"name": st["name"], "syncMode": "full_refresh_overwrite",
                                        "selectedFields": [{"fieldPath": [f]} for f in
                                                           ("_airbyte_data", "_ab_source_file_url",
                                                            "_ab_source_file_last_modified")]}
                                       for st in s3_streams]}}, "connectionId")

    # ---------------- flux 3 : EspoCRM
    step("Source MySQL (EspoCRM, compte lecture seule) -> bronze")
    s_crm = ensure("sources", ws, "espocrm_mariadb", {"configuration": {
        "sourceType": "mysql", "host": H, "port": int(env.get("MARIADB_HOST_PORT", 3306)), "database": env["MARIADB_DATABASE"],
        "username": "airbyte", "password": env["AIRBYTE_MARIADB_PASSWORD"],
        "ssl_mode": {"mode": "preferred"}, "replication_method": {"method": "STANDARD"},
        "tunnel_method": {"tunnel_method": "NO_TUNNEL"}}}, "sourceId")
    crm_streams = [{"name": t, "syncMode": "incremental_append", "cursorField": ["modified_at"]}
                   for t in ("account", "contact", "opportunity")]
    crm_streams += [{"name": t, "syncMode": "full_refresh_overwrite"}
                    for t in ("email_address", "entity_email_address", "phone_number", "entity_phone_number")]
    c_crm = ensure("connections", ws, "espocrm -> bronze", {
        "sourceId": s_crm, "destinationId": d_bronze, "schedule": {"scheduleType": "manual"},
        "namespaceDefinition": "destination", "prefix": "crm_",
        "configurations": {"streams": crm_streams}}, "connectionId")

    if not args.no_sync:
        step("Synchronisations Bronze")
        sync(c_raw_bronze, "minio_raw -> bronze")
        sync(c_crm, "espocrm -> bronze")

    print("\nTerminé. Étape suivante : ./scripts/run_silver.sh  (Windows : scripts\\run_silver.ps1)")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as e:
        print("\nERREUR API Airbyte :\n" + str(e))
        print("\nAstuce : si un champ de configuration est refusé (version de connecteur différente),"
              "\ncréez cet objet à la main en suivant docs/02_flux_airbyte.md puis relancez le script.")
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)

# =====================================================================
# scripts/setup_minio.ps1  (Windows PowerShell)
# Équivalent de setup_minio.sh : bucket privé dsid-raw + préfixes + user Airbyte.
# Usage : powershell -ExecutionPolicy Bypass -File scripts\setup_minio.ps1
# =====================================================================
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path ".env")) { throw "Fichier .env absent (Copy-Item .env.example .env)" }
Get-Content .env | Where-Object { $_ -match '^\s*[A-Z_]+=' } | ForEach-Object {
  $k, $v = $_ -split '=', 2; Set-Item -Path "Env:$($k.Trim())" -Value $v.Trim()
}

$MC_IMAGE = if ($env:MC_IMAGE) { $env:MC_IMAGE } else { "minio/mc:latest" }
$NET      = "dsid-bigdata-network"
$BUCKET   = if ($env:MINIO_BUCKET) { $env:MINIO_BUCKET } else { "dsid-raw" }
$HOSTVAR  = "MC_HOST_local=http://$($env:MINIO_ROOT_USER):$($env:MINIO_ROOT_PASSWORD)@minio:9000"
$POLDIR   = (Resolve-Path ".\minio").Path

function mc { docker run --rm --network $NET -v "${POLDIR}:/policies:ro" -e $HOSTVAR $MC_IMAGE @args }

Write-Host "== Bucket $BUCKET"
mc mb --ignore-existing "local/$BUCKET"
mc anonymous set none "local/$BUCKET"

Write-Host "== Préfixes"
foreach ($p in @("raw/api/tmdb", "raw/csv/cinemas_idf")) {
  "prefix $p" | docker run --rm -i --network $NET -e $HOSTVAR $MC_IMAGE pipe "local/$BUCKET/$p/.keep"
}

Write-Host "== Utilisateur Airbyte + policy"
mc admin user add local $env:MINIO_AIRBYTE_ACCESS_KEY $env:MINIO_AIRBYTE_SECRET_KEY
try { mc admin policy create local airbyte-raw-rw /policies/policy-airbyte-raw.json } catch { Write-Host "(policy déjà existante)" }
try { mc admin policy attach local airbyte-raw-rw --user $env:MINIO_AIRBYTE_ACCESS_KEY } catch { Write-Host "(policy déjà attachée)" }

mc ls --recursive "local/$BUCKET"
Write-Host "OK : bucket $BUCKET prêt."

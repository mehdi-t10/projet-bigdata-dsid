# =====================================================================
# scripts/run_silver.ps1 — Construit Silver + contrôles (Windows PowerShell)
# Usage : powershell -ExecutionPolicy Bypass -File scripts\run_silver.ps1
# =====================================================================
Set-Location (Join-Path $PSScriptRoot "..")
Get-Content .env | Where-Object { $_ -match '^\s*[A-Z_]+=' } | ForEach-Object {
  $k, $v = $_ -split '=', 2; Set-Item -Path "Env:$($k.Trim())" -Value $v.Trim()
}
New-Item -ItemType Directory -Force -Path logs | Out-Null
$log  = "logs\run_silver_$(Get-Date -Format yyyyMMdd_HHmmss).log"
$gitv = try { git rev-parse --short HEAD 2>$null } catch { "hors-git" }
docker exec -i dsid-postgres psql -U $env:POSTGRES_USER -d $env:POSTGRES_DB `
  -v ON_ERROR_STOP=1 -v git_version=$gitv -f /sql/run_all.sql 2>&1 | Tee-Object -FilePath $log
$rc = $LASTEXITCODE
Write-Host "Journal : $log (code retour $rc)"
exit $rc

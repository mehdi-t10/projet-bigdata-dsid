#!/bin/bash
# =====================================================================
# init/mariadb/01_airbyte_readonly.sh
# Crée le compte MariaDB 'airbyte' en LECTURE SEULE sur la base EspoCRM.
# Exécuté au premier démarrage du volume mariadb_data.
# Si MariaDB tourne déjà :
#   docker exec -i dsid-mariadb bash < init/mariadb/01_airbyte_readonly.sh
# =====================================================================
set -euo pipefail

DB="${MARIADB_DATABASE:-espocrm}"
PWD_AB="${AIRBYTE_MARIADB_PASSWORD:?AIRBYTE_MARIADB_PASSWORD manquant}"
ROOT_PWD="${MARIADB_ROOT_PASSWORD:?MARIADB_ROOT_PASSWORD manquant}"

mariadb -uroot -p"${ROOT_PWD}" <<EOSQL
CREATE USER IF NOT EXISTS 'airbyte'@'%' IDENTIFIED BY '${PWD_AB}';
ALTER USER 'airbyte'@'%' IDENTIFIED BY '${PWD_AB}';
-- Lecture seule : SELECT sur la base CRM uniquement
GRANT SELECT ON \`${DB}\`.* TO 'airbyte'@'%';
-- Nécessaire au connecteur MySQL d'Airbyte pour lister le catalogue / lire les positions
GRANT REPLICATION CLIENT, REPLICATION SLAVE ON *.* TO 'airbyte'@'%';
FLUSH PRIVILEGES;
SHOW GRANTS FOR 'airbyte'@'%';
EOSQL

echo "[init] Compte MariaDB 'airbyte' en lecture seule sur ${DB}."

-- =====================================================================
-- init/postgres/01_schemas.sql
-- Exécuté automatiquement au PREMIER démarrage du volume postgres_data.
-- Si la base existe déjà : docker exec -i dsid-postgres psql -U warehouse -d warehouse < init/postgres/01_schemas.sql
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS bronze;   -- données brutes chargées par Airbyte (aucune transformation)
CREATE SCHEMA IF NOT EXISTS silver;   -- données nettoyées / typées / dédoublonnées (SQL versionné)

-- unaccent : utilisé pour normaliser les en-têtes CSV et les noms (rapprochements)
CREATE EXTENSION IF NOT EXISTS unaccent;

COMMENT ON SCHEMA bronze IS 'Couche Bronze : copie fidèle des sources (API TMDB, CSV cinémas IDF, EspoCRM) chargée par Airbyte';
COMMENT ON SCHEMA silver IS 'Couche Silver : tables nettoyées, typées, dédoublonnées et tracées, construites en SQL (sql/silver)';

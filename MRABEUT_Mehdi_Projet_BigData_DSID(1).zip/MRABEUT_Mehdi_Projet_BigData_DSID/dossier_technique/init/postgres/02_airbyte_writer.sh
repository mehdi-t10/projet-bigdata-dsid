#!/bin/bash
# =====================================================================
# init/postgres/02_airbyte_writer.sh
# Crée le compte PostgreSQL utilisé par Airbyte (destination).
# Principe du moindre privilège : Airbyte écrit UNIQUEMENT dans bronze
# (+ son schéma interne airbyte_internal), et ne peut pas toucher silver.
# =====================================================================
# NB : ce script peut être "sourcé" par docker-entrypoint.sh (si non exécutable),
# on n'utilise donc ni "exit" ni "set -e" au niveau global.

AB_USER="${AIRBYTE_PG_USER:-airbyte_writer}"

if [ -z "${AIRBYTE_PG_PASSWORD:-}" ]; then
  echo "[init] AIRBYTE_PG_PASSWORD vide : compte Airbyte non créé (utilisez POSTGRES_USER dans Airbyte)."
else
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
     -v ab_user="$AB_USER" -v ab_pwd="$AIRBYTE_PG_PASSWORD" -v db="$POSTGRES_DB" <<'EOSQL'
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'ab_user', :'ab_pwd')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'ab_user') \gexec

-- Airbyte (Destinations V2) crée ses tables brutes dans airbyte_internal
CREATE SCHEMA IF NOT EXISTS airbyte_internal;

SELECT format('GRANT CONNECT, TEMP ON DATABASE %I TO %I', :'db', :'ab_user') \gexec
SELECT format('GRANT USAGE, CREATE ON SCHEMA bronze TO %I', :'ab_user') \gexec
SELECT format('GRANT USAGE, CREATE ON SCHEMA airbyte_internal TO %I', :'ab_user') \gexec
SELECT format('ALTER SCHEMA airbyte_internal OWNER TO %I', :'ab_user') \gexec
-- Aucun droit sur silver : séparation stricte ingestion / transformation
SELECT format('REVOKE ALL ON SCHEMA silver FROM %I', :'ab_user') \gexec
EOSQL
echo "[init] Compte Airbyte '$AB_USER' créé (écriture sur bronze uniquement)."
fi

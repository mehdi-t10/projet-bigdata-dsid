#!/usr/bin/env python3
"""
sql/dev/generate_fixtures.py
Génère sql/dev/fake_bronze.sql : un schéma bronze SIMULÉ, de même forme que
celui produit par Airbyte, pour tester le SQL Silver et les contrôles SANS
Airbyte (développement / démonstration / correction).

!! Ces données sont FICTIVES. Ne jamais les charger dans la base du rendu
   après les vraies synchronisations Airbyte (le script DROP le schéma bronze).

Anomalies volontairement injectées (pour prouver que les contrôles marchent) :
  - films présents dans 2 extractions (doublons inter-fichiers) et dans 2 listes
  - un film avec release_date invalide ("2026-13-45")
  - une ligne CSV cinéma ré-ingérée (doublon) + une ligne sans nom
  - en-têtes CSV avec accents/espaces ("Entrées 2022", "N° auto", "écrans")
  - un contact en 2 versions (sync incrémentale append) + un contact supprimé
  - un e-mail invalide, une opportunité liée à un film TMDB inconnu
"""
import json, uuid, random
from datetime import datetime, timedelta, timezone

random.seed(42)
NOW = datetime.now(timezone.utc).replace(microsecond=0)
D1, D2 = NOW - timedelta(days=1, hours=2), NOW - timedelta(hours=3)
out = []

def q(v):
    if v is None: return "NULL"
    if isinstance(v, (dict, list)): return "'" + json.dumps(v, ensure_ascii=False).replace("'", "''") + "'::jsonb"
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, (int, float)): return str(v)
    if isinstance(v, datetime): return f"'{v.isoformat()}'::timestamptz"
    return "'" + str(v).replace("'", "''") + "'"

S3_DDL = """CREATE TABLE bronze.{t} (
  _airbyte_raw_id varchar NOT NULL, _airbyte_extracted_at timestamptz NOT NULL,
  _airbyte_meta jsonb NOT NULL DEFAULT '{{}}', _airbyte_generation_id bigint,
  _airbyte_data jsonb, _ab_source_file_url varchar, _ab_source_file_last_modified varchar);"""

def s3_rows(table, prefix, batches):
    out.append(S3_DDL.format(t=table))
    for ts, recs in batches:
        f = f"{prefix}/{ts:%Y_%m_%d}_{int(ts.timestamp())}_0.jsonl"
        for r in recs:
            out.append(f"INSERT INTO bronze.{table} VALUES ({q(str(uuid.uuid4()))}, {q(NOW)}, '{{}}', 1, "
                       f"{q(r)}, {q(f)}, {q(ts.isoformat())});")

out.append("-- FICHIER GÉNÉRÉ par sql/dev/generate_fixtures.py — DONNÉES FICTIVES DE TEST")
out.append("DROP SCHEMA IF EXISTS bronze CASCADE; CREATE SCHEMA bronze;")

# ---------------- Flux 1 : TMDB ----------------
genres = [(28,"Action"),(12,"Aventure"),(16,"Animation"),(35,"Comédie"),(80,"Crime"),(99,"Documentaire"),
          (18,"Drame"),(10751,"Familial"),(14,"Fantastique"),(36,"Histoire"),(27,"Horreur"),(10402,"Musique"),
          (9648,"Mystère"),(10749,"Romance"),(878,"Science-Fiction"),(10770,"Téléfilm"),(53,"Thriller"),
          (10752,"Guerre"),(37,"Western")]
g = [{"id": i, "name": n, "_src_language": "fr-FR"} for i, n in genres]
s3_rows("tmdb_genres", "raw/api/tmdb/genres", [(D1, g), (D2, g)])

def film(i, lt, pop):
    return {"id": i, "title": f"Film de test {i}", "original_title": f"Test movie {i}", "original_language": "fr",
            "overview": "  Synopsis   de test  ", "release_date": f"2026-0{1+i%9}-1{i%9}",
            "popularity": pop, "vote_average": round(5 + (i % 40) / 10, 1), "vote_count": 100 + i,
            "adult": False, "video": False, "genre_ids": [18, 35] if i % 2 else [28, 878],
            "poster_path": f"/p{i}.jpg", "_list_type": lt, "_src_language": "fr-FR", "_src_region": "FR"}

now_ids, pop_ids, trend_ids = list(range(1001, 1013)), list(range(1008, 1020)), list(range(1015, 1022))
np1 = [film(i, "now_playing", 50.0 + i % 7) for i in now_ids]
np2 = [film(i, "now_playing", 55.5 + i % 5) for i in now_ids]
np2[0]["release_date"] = "2026-13-45"                       # anomalie TYPES
s3_rows("tmdb_movies_now_playing", "raw/api/tmdb/movies_now_playing", [(D1, np1), (D2, np2)])
s3_rows("tmdb_movies_popular", "raw/api/tmdb/movies_popular", [(D2, [film(i, "popular", 80.0 + i % 9) for i in pop_ids])])
s3_rows("tmdb_trending_week", "raw/api/tmdb/trending_week", [(D2, [film(i, "trending_week", 30.0 + i % 3) for i in trend_ids])])
det = [{"id": i, "imdb_id": f"tt{i:07d}", "title": f"Film de test {i}", "runtime": 90 + i % 50,
        "budget": 0 if i % 3 == 0 else 1_000_000 * (i % 20), "revenue": 0, "status": "Released",
        "release_date": f"2026-0{1+i%9}-1{i%9}", "genres": [{"id": 18, "name": "Drame"}],
        "production_countries": [{"iso_3166_1": "FR", "name": "France"}] + ([{"iso_3166_1": "US", "name": "United States of America"}] if i % 2 else []),
        "vote_average": 6.5, "vote_count": 10, "popularity": 3.2, "_src_language": "fr-FR"} for i in now_ids]
s3_rows("tmdb_movie_details", "raw/api/tmdb/movie_details", [(D2, det)])

# ---------------- Flux 2 : CSV cinémas IDF ----------------
cin = [  # valeurs numériques FICTIVES
 ("1001","UGC Ciné Cité Les Halles","7 place de la Rotonde","75101","Paris","75",27,3913,"48,8625","2,3470","NON","OUI"),
 ("1002","MK2 Bibliothèque","128 avenue de France","75113","Paris","75",20,3500,"48.8326","2.3762","OUI","OUI"),
 ("1003","Le Grand Rex","1 boulevard Poissonnière","75102","Paris","75",7,3200,"48.8707","2.3477","NON","OUI"),
 ("1004","Pathé Massy","Place du Grand Ouest","91377","Massy","91",14,2600,"48.7275","2.2730","NON","OUI"),
 ("1005","Cinéma Jacques Prévert","4 rue Jacques Prévert","91421","Morsang-sur-Orge","91",2,350,"48.6600","2.3500","AE","NON"),
 ("1006","Cinéma Paul Éluard","Place du Marché","94016","Cachan","94",1,220,"48.7900","2.3300","AE","NON"),
 ("1007","CGR Brétigny","Rue Henri Douard","91103","Brétigny-sur-Orge","91",10,1900,"48.6100","2.3100","NON","OUI"),
 ("1008","Le Méliès","12 place Jean Jaurès","93048","Montreuil","93",6,800,"48.8610","2.4410","AE","NON"),
 ("1009","Pathé La Villette","30 avenue Corentin Cariou","75119","Paris","75",16,3100,"48.8930","2.3880","NON","OUI"),
 ("1010","Ciné 220","3 rue Chanzy","91103","Brétigny-sur-Orge","91",3,400,"48.6080","2.3060","AE","NON"),
]
H = ["N° auto","nom","région administrative","adresse","code INSEE","commune","DEP","écrans","fauteuils",
     "séances","entrées 2022","entrées 2021","propriétaire","programmateur","AE","multiplexe","latitude","longitude"]
def crow(c):
    return dict(zip(H, [c[0], c[1], "ILE-DE-FRANCE", c[2], c[3], c[4], c[5], c[6], c[7],
                        c[6] * 1500, c[7] * 280, c[7] * 250, "Exploitant test", "Programmation test",
                        c[10], c[11], c[8], c[9]]))
rows = [crow(c) for c in cin]
rows_dup = rows + [crow(cin[3])] + [dict(zip(H, ["1099", "", "ILE-DE-FRANCE"] + [""] * 15))]  # doublon + sans nom
s3_rows("csv_cinemas_idf", "raw/csv/cinemas_idf", [(D2, rows_dup)])

# ---------------- Flux 3 : CRM EspoCRM (tables typées, préfixe crm_) ----------------
AB = "_airbyte_raw_id varchar NOT NULL, _airbyte_extracted_at timestamptz NOT NULL, _airbyte_meta jsonb NOT NULL DEFAULT '{}', _airbyte_generation_id bigint"
out.append(f"""CREATE TABLE bronze.crm_account (id varchar, name varchar, deleted boolean, website varchar, type varchar,
  industry varchar, billing_address_street varchar, billing_address_city varchar, billing_address_postal_code varchar,
  billing_address_country varchar, c_cnc_id varchar, created_at timestamp, modified_at timestamp, {AB});""")
out.append(f"""CREATE TABLE bronze.crm_contact (id varchar, deleted boolean, salutation_name varchar, first_name varchar,
  last_name varchar, account_id varchar, address_city varchar, address_postal_code varchar,
  created_at timestamp, modified_at timestamp, {AB});""")
out.append(f"""CREATE TABLE bronze.crm_opportunity (id varchar, name varchar, deleted boolean, amount double precision,
  amount_currency varchar, stage varchar, probability int, lead_source varchar, close_date date, account_id varchar,
  contact_id varchar, c_tmdb_id varchar, created_at timestamp, modified_at timestamp, {AB});""")
out.append(f"CREATE TABLE bronze.crm_email_address (id varchar, name varchar, lower varchar, invalid boolean, opt_out boolean, deleted boolean, {AB});")
out.append(f"CREATE TABLE bronze.crm_entity_email_address (id bigint, entity_id varchar, email_address_id varchar, entity_type varchar, \"primary\" boolean, deleted boolean, {AB});")

def ins(t, cols, vals):
    rid = str(uuid.uuid4())
    out.append(f"INSERT INTO bronze.{t} ({', '.join(cols)}, _airbyte_raw_id, _airbyte_extracted_at, _airbyte_generation_id) "
               f"VALUES ({', '.join(q(v) for v in vals)}, {q(rid)}, {q(NOW)}, 1);")

t0 = (NOW - timedelta(days=10)).replace(tzinfo=None)
acc = [("6a1f0c2b9d3e4f501","Pathé Massy","Customer","Entertainment","Massy","91300","1004"),
       ("6a1f0c2b9d3e4f502","Cinéma Jacques Prévert","Customer","Entertainment","Morsang-sur-Orge","91390",None),
       ("6a1f0c2b9d3e4f503","Le Méliès","Partner","Entertainment","Montreuil","93100",None),
       ("6a1f0c2b9d3e4f504","Distribution Test SAS","Investor","Finance","Paris","75008",None)]
for a in acc:
    ins("crm_account", ["id","name","deleted","website","type","industry","billing_address_city","billing_address_postal_code","billing_address_country","c_cnc_id","created_at","modified_at"],
        [a[0], a[1], False, "https://exemple.test", a[2], a[3], a[4], a[5], "France", a[6], t0, t0])
con = [("7b2e1d3c0a4f5e601","Mr.","claire","martin","6a1f0c2b9d3e4f501","claire.martin@exemple.test"),
       ("7b2e1d3c0a4f5e602","Ms.","lucas ","Bernard","6a1f0c2b9d3e4f502","lucas.bernard@exemple"),   # e-mail invalide
       ("7b2e1d3c0a4f5e603","Mr.","Nina","Petit","6a1f0c2b9d3e4f503","nina.petit@exemple.test"),
       ("7b2e1d3c0a4f5e604","Mr.","Hugo","Durand","6a1f0c2b9d3e4f504",None)]
for c in con:
    ins("crm_contact", ["id","deleted","salutation_name","first_name","last_name","account_id","address_city","created_at","modified_at"],
        [c[0], False, c[1], c[2], c[3], c[4], "Massy", t0, t0])
# 2e version du contact 1 (modification de la ville) + contact supprimé
ins("crm_contact", ["id","deleted","salutation_name","first_name","last_name","account_id","address_city","created_at","modified_at"],
    [con[0][0], False, "Mr.", "Claire", "MARTIN", con[0][4], "Palaiseau", t0, t0 + timedelta(days=2)])
ins("crm_contact", ["id","deleted","salutation_name","first_name","last_name","account_id","address_city","created_at","modified_at"],
    ["7b2e1d3c0a4f5e699", True, "Mr.", "Supprimé", "Test", None, None, t0, t0])
for k, c in enumerate(con):
    if c[5]:
        eid = f"8c3f{k:013d}"
        ins("crm_email_address", ["id","name","lower","invalid","opt_out","deleted"], [eid, c[5], c[5].lower(), False, False, False])
        ins("crm_entity_email_address", ["id","entity_id","email_address_id","entity_type","\"primary\"","deleted"], [k+1, c[0], eid, "Contact", True, False])
opp = [("9d4a2e5f1b6c7d801","Programmation Film de test 1001 - Pathé Massy",12000,"Negotiation",60,acc[0][0],con[0][0],"1001"),
       ("9d4a2e5f1b6c7d802","Programmation Film de test 1005 - Prévert",3500,"Closed Won",100,acc[1][0],con[1][0],"1005"),
       ("9d4a2e5f1b6c7d803","Avant-première Méliès",1800,"Proposal",40,acc[2][0],con[2][0],"999999"),  # film inconnu
       ("9d4a2e5f1b6c7d804","Cycle documentaire",900,"Closed Lost",0,acc[2][0],None,None)]
for o in opp:
    ins("crm_opportunity", ["id","name","deleted","amount","amount_currency","stage","probability","lead_source","close_date","account_id","contact_id","c_tmdb_id","created_at","modified_at"],
        [o[0], o[1], False, o[2], "EUR", o[3], o[4], "Web Site", (NOW + timedelta(days=30)).date().isoformat(), o[5], o[6], o[7], t0, t0])

open(__file__.replace("generate_fixtures.py", "fake_bronze.sql"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print(f"fake_bronze.sql : {len(out)} instructions")

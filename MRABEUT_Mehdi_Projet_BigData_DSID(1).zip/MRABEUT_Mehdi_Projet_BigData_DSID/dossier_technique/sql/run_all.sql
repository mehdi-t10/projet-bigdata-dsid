-- =====================================================================
-- sql/run_all.sql — Orchestration Bronze -> Silver + contrôles
-- Usage (depuis la racine du projet, conteneur démarré) :
--   docker exec -i dsid-postgres psql -U warehouse -d warehouse -v ON_ERROR_STOP=1 -f /sql/run_all.sql
-- (le dossier ./sql est monté en lecture seule sur /sql, cf. compose.yaml)
-- Idempotent : peut être relancé autant de fois que nécessaire.
-- Code retour : 0 si aucun contrôle BLOQUANT en échec, sinon 3.
-- =====================================================================
\set ON_ERROR_STOP on
\set QUIET on
SET client_min_messages = warning;
\pset footer off

\echo '== 1/5 Fonctions et tables techniques'
\ir silver/00_functions.sql

-- Ouverture du run (journal) -> variable :run_id
-- (optionnel : psql -v git_version=$(git rev-parse --short HEAD) ...)
\if :{?git_version}
\else
  \set git_version ''
\endif
INSERT INTO silver.etl_run_log (git_version, comment)
VALUES (NULLIF(:'git_version', ''), 'run_all.sql')
RETURNING run_id \gset
\echo '   run_id =' :run_id

\echo '== 2/5 Précontrôles Bronze (bloquants)'
\o /dev/null
\ir tests/00_prechecks_bronze.sql
\o

\echo '== 3/5 Vues de staging sur Bronze'
\o /dev/null
\ir silver/01_staging_views.sql
\o

\echo '== 4/5 Construction Silver (transaction unique : tout ou rien)'
BEGIN;
\ir silver/10_tmdb.sql
\ir silver/20_cinemas.sql
\ir silver/30_crm.sql
\ir silver/40_conformed.sql
COMMIT;

\echo '== 5/5 Contrôles qualité Silver'
\o /dev/null
\ir tests/10_dq_silver.sql
\o
\ir tests/99_report.sql

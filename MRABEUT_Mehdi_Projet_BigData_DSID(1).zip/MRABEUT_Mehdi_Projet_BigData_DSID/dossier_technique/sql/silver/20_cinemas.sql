-- =====================================================================
-- sql/silver/20_cinemas.sql — Flux 2 (CSV établissements cinématographiques IDF)
-- Source : data.iledefrance.fr / CNC (Licence Ouverte), CSV séparateur ';'
-- Règles : normalisation des en-têtes (accents/espaces), typage, codes INSEE
--          sur 5 caractères, département dérivé, coordonnées, booléens AE/multiplexe,
--          dédoublonnage par identifiant CNC (dernier fichier), traçabilité.
-- =====================================================================

-- Premier champ non vide parmi plusieurs noms possibles (en-têtes variables selon export)
CREATE OR REPLACE FUNCTION silver.f_pick(j jsonb, keys text[]) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT silver.f_clean_text(j->>k)
  FROM unnest(keys) WITH ORDINALITY AS t(k, o)
  WHERE silver.f_clean_text(j->>k) IS NOT NULL
  ORDER BY o LIMIT 1
$$;

-- Colonne "entrées" la plus récente (ex. entrees_2022 > entrees_2021)
CREATE OR REPLACE FUNCTION silver.f_latest_entrees(j jsonb, OUT entrees_year int, OUT entrees bigint)
LANGUAGE sql IMMUTABLE AS $$
  SELECT substring(k from '(\d{4})$')::int, silver.f_to_int(v)
  FROM jsonb_each_text(j) AS e(k, v)
  WHERE k ~ '^entrees_\d{4}$' AND silver.f_to_int(v) IS NOT NULL
  ORDER BY k DESC LIMIT 1
$$;

DROP TABLE IF EXISTS silver.cinema_idf CASCADE;
CREATE TABLE silver.cinema_idf (
  cinema_id            text         PRIMARY KEY,      -- N° auto CNC (ou hash si absent)
  cinema_name          text         NOT NULL,
  cinema_name_norm     text         NOT NULL,         -- pour rapprochement CRM
  address              text,
  commune              text,
  code_insee           char(5),
  departement          char(2),
  nb_ecrans            integer,
  nb_fauteuils         integer,
  nb_seances           integer,
  entrees              bigint,
  entrees_year         smallint,
  proprietaire         text,
  programmateur        text,
  is_art_et_essai      boolean,
  is_multiplexe        boolean,
  latitude             numeric(9,6),
  longitude            numeric(9,6),
  id_is_surrogate      boolean      NOT NULL,         -- true si l'id a été calculé (hash)
  bronze_raw_id        text         NOT NULL,
  source_file          text,
  data_as_of           timestamptz  NOT NULL,
  silver_loaded_at     timestamptz  NOT NULL DEFAULT now()
);

WITH src AS (
  SELECT silver.f_norm_keys(payload) AS j, bronze_raw_id, source_file,
         COALESCE(source_file_modified, bronze_extracted_at) AS data_as_of, bronze_extracted_at
  FROM silver.stg_csv_cinemas_idf
),
typed AS (
  SELECT
    silver.f_pick(j, ARRAY['n_auto','ndeg_auto','no_auto','numero_auto','num_auto','n_auto_cnc','id'])     AS raw_id,
    silver.f_pick(j, ARRAY['nom_de_l_etablissement','nom','nom_etablissement','nom_du_cinema','etablissement'])                     AS cinema_name,
    silver.f_pick(j, ARRAY['adresse','adresse_postale','adresse_postale_complete'])                                                    AS address,
    silver.f_pick(j, ARRAY['commune','ville','nom_commune'])                                                AS commune,
    silver.f_pick(j, ARRAY['code_insee','insee','code_commune','codgeo'])                                   AS code_insee_raw,
    silver.f_pick(j, ARRAY['dep','departement','code_departement'])                                         AS dep_raw,
    silver.f_to_int(silver.f_pick(j, ARRAY['ecrans','nombre_d_ecrans','nb_ecrans']))::int                  AS nb_ecrans,
    silver.f_to_int(silver.f_pick(j, ARRAY['fauteuils','nombre_de_fauteuils','nb_fauteuils']))::int        AS nb_fauteuils,
    silver.f_to_int(silver.f_pick(j, ARRAY['seances','nombre_de_seances']))::int                           AS nb_seances,
    COALESCE((silver.f_latest_entrees(j)).entrees, silver.f_to_int(j->>'entrees'))                          AS entrees,
    (silver.f_latest_entrees(j)).entrees_year                                                               AS entrees_year,
    silver.f_pick(j, ARRAY['proprietaire'])                                                                 AS proprietaire,
    silver.f_pick(j, ARRAY['programmateur'])                                                                AS programmateur,
    silver.f_pick(j, ARRAY['ae','art_et_essai','categorie_art_et_essai','label_art_et_essai'])             AS ae_raw,
    silver.f_pick(j, ARRAY['multiplexe'])                                                                   AS multiplexe_raw,
    COALESCE(silver.f_to_num(silver.f_pick(j, ARRAY['latitude','lat'])),
             silver.f_to_num(split_part(silver.f_pick(j, ARRAY['geo','geolocalisation','coordonnees','geo_point_2d']), ',', 1))) AS latitude,
    COALESCE(silver.f_to_num(silver.f_pick(j, ARRAY['longitude','lon','lng'])),
             silver.f_to_num(split_part(silver.f_pick(j, ARRAY['geo','geolocalisation','coordonnees','geo_point_2d']), ',', 2))) AS longitude,
    bronze_raw_id, source_file, data_as_of, bronze_extracted_at
  FROM src
),
keyed AS (
  SELECT t.*,
         CASE WHEN t.code_insee_raw ~ '^\d[\dAB]\d{2,3}$' THEN lpad(t.code_insee_raw, 5, '0') END AS code_insee,
         COALESCE(t.raw_id, 'H_' || left(md5(concat_ws('|', silver.f_norm_name(t.cinema_name),
                                                         silver.f_norm_name(t.commune),
                                                         silver.f_norm_name(t.address))), 16)) AS cinema_id,
         t.raw_id IS NULL AS id_is_surrogate
  FROM typed t
  WHERE t.cinema_name IS NOT NULL                       -- ligne inexploitable sans nom
)
INSERT INTO silver.cinema_idf
SELECT DISTINCT ON (cinema_id)
       cinema_id,
       cinema_name,
       silver.f_norm_name(cinema_name),
       address,
       commune,
       code_insee,
       COALESCE(CASE WHEN dep_raw ~ '^\d{1,2}$' THEN lpad(dep_raw, 2, '0') END, left(code_insee, 2)),
       nb_ecrans, nb_fauteuils, nb_seances, entrees, entrees_year,
       proprietaire, programmateur,
       CASE WHEN ae_raw IS NULL THEN false
            WHEN upper(ae_raw) IN ('AE','OUI','O','1','TRUE','X','CLASSE') THEN true
            WHEN silver.f_to_bool(ae_raw) IS NOT NULL THEN silver.f_to_bool(ae_raw)
            ELSE true END,                                -- toute catégorie AE renseignée = classé
       silver.f_to_bool(multiplexe_raw),
       round(latitude, 6), round(longitude, 6),
       id_is_surrogate,
       bronze_raw_id, source_file, data_as_of
FROM keyed
ORDER BY cinema_id, data_as_of DESC, bronze_extracted_at DESC, bronze_raw_id DESC;

CREATE INDEX IF NOT EXISTS ix_cinema_idf_name_commune ON silver.cinema_idf (cinema_name_norm, commune);
COMMENT ON TABLE silver.cinema_idf IS 'Établissements cinématographiques actifs en Île-de-France (CNC), typés et dédoublonnés. Source : bronze.csv_cinemas_idf';

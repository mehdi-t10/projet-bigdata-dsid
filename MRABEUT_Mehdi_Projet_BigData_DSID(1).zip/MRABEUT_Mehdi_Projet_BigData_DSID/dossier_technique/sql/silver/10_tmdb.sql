-- =====================================================================
-- sql/silver/10_tmdb.sql — Flux 1 (API TMDB) : Bronze -> Silver
-- Tables : tmdb_genre, tmdb_film, tmdb_film_genre, tmdb_film_country,
--          tmdb_film_list_snapshot
-- Règles : typage, nettoyage texte, dédoublonnage (dernière version par id),
--          enrichissement liste + détails, traçabilité (bronze_raw_id, source_file).
-- =====================================================================

-- ---------------------------------------------------------------------
-- silver.tmdb_genre : référentiel des genres (1 ligne par genre_id)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.tmdb_genre CASCADE;
CREATE TABLE silver.tmdb_genre (
  genre_id            integer     PRIMARY KEY,
  genre_name          text        NOT NULL,
  language            text,
  bronze_raw_id       text        NOT NULL,
  source_file         text,
  data_as_of          timestamptz NOT NULL,
  silver_loaded_at    timestamptz NOT NULL DEFAULT now()
);

INSERT INTO silver.tmdb_genre (genre_id, genre_name, language, bronze_raw_id, source_file, data_as_of)
SELECT genre_id, genre_name, language, bronze_raw_id, source_file, data_as_of
FROM (
  SELECT silver.f_to_int(payload->>'id')::int                    AS genre_id,
         silver.f_clean_text(payload->>'name')                  AS genre_name,
         payload->>'_src_language'                              AS language,
         bronze_raw_id, source_file,
         COALESCE(source_file_modified, bronze_extracted_at)    AS data_as_of,
         row_number() OVER (PARTITION BY silver.f_to_int(payload->>'id')
                            ORDER BY COALESCE(source_file_modified, bronze_extracted_at) DESC,
                                     bronze_extracted_at DESC, bronze_raw_id DESC) AS rn
  FROM silver.stg_tmdb_genres
) s
WHERE rn = 1 AND genre_id IS NOT NULL AND genre_name IS NOT NULL;

-- ---------------------------------------------------------------------
-- silver.tmdb_film : 1 ligne par film (dernière version connue)
--   attributs de liste (popularité, votes) + attributs de détail (durée, budget...)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.tmdb_film CASCADE;
CREATE TABLE silver.tmdb_film (
  film_id             integer      PRIMARY KEY,
  title               text         NOT NULL,
  original_title      text,
  original_language   char(2),
  overview            text,
  release_date        date,
  release_year        smallint,
  runtime_min         integer,
  budget_usd          bigint,
  revenue_usd         bigint,
  status              text,
  imdb_id             text,
  popularity          numeric(12,4),
  vote_average        numeric(4,2),
  vote_count          integer,
  is_adult            boolean,
  in_now_playing      boolean      NOT NULL DEFAULT false,
  in_popular          boolean      NOT NULL DEFAULT false,
  in_trending_week    boolean      NOT NULL DEFAULT false,
  has_details         boolean      NOT NULL DEFAULT false,
  first_seen_at       timestamptz  NOT NULL,
  last_seen_at        timestamptz  NOT NULL,
  bronze_table        text         NOT NULL,
  bronze_raw_id       text         NOT NULL,
  source_file         text,
  silver_loaded_at    timestamptz  NOT NULL DEFAULT now()
);

WITH lists AS (            -- toutes les apparitions dans les listes
  SELECT list_type,
         silver.f_to_int(payload->>'id')::int                  AS film_id,
         payload, bronze_table, bronze_raw_id, source_file,
         COALESCE(source_file_modified, bronze_extracted_at)   AS data_as_of,
         bronze_extracted_at
  FROM silver.stg_tmdb_movie_lists
  WHERE silver.f_to_int(payload->>'id') IS NOT NULL
),
lists_last AS (            -- dernière version par film (dédoublonnage)
  SELECT DISTINCT ON (film_id) *
  FROM lists
  ORDER BY film_id, data_as_of DESC, bronze_extracted_at DESC, bronze_raw_id DESC
),
lists_agg AS (             -- appartenance aux listes + première/dernière apparition
  SELECT film_id,
         bool_or(list_type = 'now_playing')   AS in_now_playing,
         bool_or(list_type = 'popular')       AS in_popular,
         bool_or(list_type = 'trending_week') AS in_trending_week,
         min(data_as_of) AS first_seen_at,
         max(data_as_of) AS last_seen_at
  FROM lists GROUP BY film_id
),
details_last AS (
  SELECT DISTINCT ON (silver.f_to_int(payload->>'id'))
         silver.f_to_int(payload->>'id')::int                 AS film_id,
         payload, bronze_table, bronze_raw_id, source_file,
         COALESCE(source_file_modified, bronze_extracted_at)  AS data_as_of
  FROM silver.stg_tmdb_movie_details
  WHERE silver.f_to_int(payload->>'id') IS NOT NULL
  ORDER BY silver.f_to_int(payload->>'id'),
           COALESCE(source_file_modified, bronze_extracted_at) DESC, bronze_extracted_at DESC, bronze_raw_id DESC
),
films AS (
  SELECT COALESCE(l.film_id, d.film_id) AS film_id, l.payload AS lp, d.payload AS dp,
         l.bronze_table AS l_table, l.bronze_raw_id AS l_raw, l.source_file AS l_file,
         d.bronze_table AS d_table, d.bronze_raw_id AS d_raw, d.source_file AS d_file,
         d.data_as_of AS d_asof
  FROM lists_last l
  FULL JOIN details_last d ON d.film_id = l.film_id
)
INSERT INTO silver.tmdb_film
SELECT f.film_id,
       COALESCE(silver.f_clean_text(f.dp->>'title'), silver.f_clean_text(f.lp->>'title'), '(sans titre)'),
       silver.f_clean_text(COALESCE(f.dp->>'original_title', f.lp->>'original_title')),
       NULLIF(lower(left(COALESCE(f.dp->>'original_language', f.lp->>'original_language'), 2)), ''),
       silver.f_clean_text(COALESCE(f.dp->>'overview', f.lp->>'overview')),
       silver.f_to_date(COALESCE(f.dp->>'release_date', f.lp->>'release_date')),
       extract(year FROM silver.f_to_date(COALESCE(f.dp->>'release_date', f.lp->>'release_date')))::smallint,
       NULLIF(silver.f_to_int(f.dp->>'runtime'), 0)::int,           -- 0 = inconnu chez TMDB
       NULLIF(silver.f_to_int(f.dp->>'budget'), 0),
       NULLIF(silver.f_to_int(f.dp->>'revenue'), 0),
       silver.f_clean_text(f.dp->>'status'),
       NULLIF(f.dp->>'imdb_id', ''),
       round(silver.f_to_num(COALESCE(f.lp->>'popularity', f.dp->>'popularity')), 4),
       round(silver.f_to_num(COALESCE(f.lp->>'vote_average', f.dp->>'vote_average')), 2),
       silver.f_to_int(COALESCE(f.lp->>'vote_count', f.dp->>'vote_count'))::int,
       silver.f_to_bool(COALESCE(f.lp->>'adult', f.dp->>'adult')),
       COALESCE(a.in_now_playing, false),
       COALESCE(a.in_popular, false),
       COALESCE(a.in_trending_week, false),
       f.dp IS NOT NULL,
       COALESCE(a.first_seen_at, f.d_asof),
       COALESCE(a.last_seen_at, f.d_asof),
       COALESCE(f.l_table, f.d_table),
       COALESCE(f.l_raw, f.d_raw),
       COALESCE(f.l_file, f.d_file)
FROM films f
LEFT JOIN lists_agg a ON a.film_id = f.film_id;

-- ---------------------------------------------------------------------
-- silver.tmdb_film_genre : table de liaison film <-> genre (N-N)
--   sources : genre_ids[] (listes) et genres[] (détails)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.tmdb_film_genre CASCADE;
CREATE TABLE silver.tmdb_film_genre (
  film_id   integer NOT NULL REFERENCES silver.tmdb_film(film_id),
  genre_id  integer NOT NULL,
  PRIMARY KEY (film_id, genre_id)
);

INSERT INTO silver.tmdb_film_genre (film_id, genre_id)
SELECT DISTINCT film_id, genre_id FROM (
  SELECT silver.f_to_int(payload->>'id')::int AS film_id, silver.f_to_int(g.value #>> '{}')::int AS genre_id
  FROM silver.stg_tmdb_movie_lists,
       LATERAL jsonb_array_elements(CASE WHEN jsonb_typeof(payload->'genre_ids') = 'array'
                                         THEN payload->'genre_ids' ELSE '[]'::jsonb END) g
  UNION
  SELECT silver.f_to_int(payload->>'id')::int, silver.f_to_int(g.value->>'id')::int
  FROM silver.stg_tmdb_movie_details,
       LATERAL jsonb_array_elements(CASE WHEN jsonb_typeof(payload->'genres') = 'array'
                                         THEN payload->'genres' ELSE '[]'::jsonb END) g
) x
WHERE film_id IN (SELECT film_id FROM silver.tmdb_film) AND genre_id IS NOT NULL;

-- ---------------------------------------------------------------------
-- silver.tmdb_film_country : pays de production (détails)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.tmdb_film_country CASCADE;
CREATE TABLE silver.tmdb_film_country (
  film_id       integer NOT NULL REFERENCES silver.tmdb_film(film_id),
  country_iso2  char(2) NOT NULL,
  country_name  text,
  PRIMARY KEY (film_id, country_iso2)
);

INSERT INTO silver.tmdb_film_country
SELECT DISTINCT ON (d.film_id, upper(c.value->>'iso_3166_1'))
       d.film_id, upper(c.value->>'iso_3166_1'), silver.f_clean_text(c.value->>'name')
FROM (SELECT DISTINCT ON (silver.f_to_int(payload->>'id')) silver.f_to_int(payload->>'id')::int AS film_id, payload
      FROM silver.stg_tmdb_movie_details
      ORDER BY silver.f_to_int(payload->>'id'), COALESCE(source_file_modified, bronze_extracted_at) DESC) d
CROSS JOIN LATERAL jsonb_array_elements(CASE WHEN jsonb_typeof(d.payload->'production_countries') = 'array'
                                             THEN d.payload->'production_countries' ELSE '[]'::jsonb END) c
WHERE d.film_id IS NOT NULL AND c.value->>'iso_3166_1' ~ '^[A-Za-z]{2}$';

-- ---------------------------------------------------------------------
-- silver.tmdb_film_list_snapshot : historique (1 ligne / film / liste / jour)
--   conserve l'évolution de la popularité entre deux extractions
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.tmdb_film_list_snapshot CASCADE;
CREATE TABLE silver.tmdb_film_list_snapshot (
  film_id        integer       NOT NULL REFERENCES silver.tmdb_film(film_id),
  list_type      text          NOT NULL CHECK (list_type IN ('now_playing','popular','trending_week')),
  snapshot_date  date          NOT NULL,
  popularity     numeric(12,4),
  vote_average   numeric(4,2),
  vote_count     integer,
  bronze_raw_id  text          NOT NULL,
  source_file    text,
  PRIMARY KEY (film_id, list_type, snapshot_date)
);

INSERT INTO silver.tmdb_film_list_snapshot
SELECT DISTINCT ON (film_id, list_type, snapshot_date)
       film_id, list_type, snapshot_date, popularity, vote_average, vote_count, bronze_raw_id, source_file
FROM (
  SELECT silver.f_to_int(payload->>'id')::int                           AS film_id,
         list_type,
         COALESCE(source_file_modified, bronze_extracted_at)::date      AS snapshot_date,
         round(silver.f_to_num(payload->>'popularity'), 4)              AS popularity,
         round(silver.f_to_num(payload->>'vote_average'), 2)            AS vote_average,
         silver.f_to_int(payload->>'vote_count')::int                   AS vote_count,
         bronze_raw_id, source_file,
         COALESCE(source_file_modified, bronze_extracted_at)            AS ts,
         bronze_extracted_at
  FROM silver.stg_tmdb_movie_lists
) s
WHERE film_id IS NOT NULL AND snapshot_date IS NOT NULL
ORDER BY film_id, list_type, snapshot_date, ts DESC, bronze_extracted_at DESC;

COMMENT ON TABLE silver.tmdb_film IS 'Films TMDB dédoublonnés (dernière version) : listes now_playing/popular/trending + détails. Source : bronze.tmdb_*';
COMMENT ON TABLE silver.tmdb_film_list_snapshot IS 'Historique quotidien de popularité/votes par film et par liste TMDB';

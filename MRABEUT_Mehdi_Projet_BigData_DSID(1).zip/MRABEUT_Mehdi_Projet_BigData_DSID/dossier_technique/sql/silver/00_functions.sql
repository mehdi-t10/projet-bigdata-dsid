-- =====================================================================
-- sql/silver/00_functions.sql
-- Fonctions utilitaires (cast "sûrs", normalisation) + tables techniques
-- (journal d'exécution, résultats des contrôles). Idempotent.
-- =====================================================================
CREATE SCHEMA IF NOT EXISTS silver;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- ---------------------------------------------------------------------
-- 1. Casts "sûrs" : renvoient NULL au lieu de planter sur une valeur invalide.
--    Les valeurs non convertibles sont ensuite COMPTÉES par les tests (catégorie TYPES).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION silver.f_clean_text(p text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(btrim(regexp_replace(p, '\s+', ' ', 'g')), '')
$$;

CREATE OR REPLACE FUNCTION silver.f_to_num(p text) RETURNS numeric
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE v text := replace(replace(btrim(p), ' ', ''), ',', '.');
BEGIN
  IF v IS NULL OR v = '' OR lower(v) IN ('null','nan','none','-') THEN RETURN NULL; END IF;
  RETURN v::numeric;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION silver.f_to_int(p text) RETURNS bigint
LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE WHEN silver.f_to_num(p) = trunc(silver.f_to_num(p))
              THEN silver.f_to_num(p)::bigint END
$$;

CREATE OR REPLACE FUNCTION silver.f_to_date(p text) RETURNS date
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE v text := btrim(p);
BEGIN
  IF v IS NULL OR v = '' THEN RETURN NULL; END IF;
  IF v ~ '^\d{4}-\d{2}-\d{2}' THEN RETURN substr(v,1,10)::date; END IF;          -- ISO
  IF v ~ '^\d{2}/\d{2}/\d{4}$' THEN RETURN to_date(v, 'DD/MM/YYYY'); END IF;     -- FR
  RETURN NULL;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION silver.f_to_ts(p text) RETURNS timestamptz
LANGUAGE plpgsql STABLE AS $$
BEGIN
  IF p IS NULL OR btrim(p) = '' THEN RETURN NULL; END IF;
  RETURN btrim(p)::timestamptz;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION silver.f_to_bool(p text) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN p IS NULL THEN NULL
    WHEN lower(btrim(p)) IN ('1','true','t','oui','o','yes','y','x') THEN true
    WHEN lower(btrim(p)) IN ('0','false','f','non','n','no','') THEN false
  END
$$;

-- ---------------------------------------------------------------------
-- 2. Normalisation
-- ---------------------------------------------------------------------
-- Clé de colonne : "Entrées 2022" -> "entrees_2022", "N° auto" -> "n_auto"
CREATE OR REPLACE FUNCTION silver.f_norm_key(p text) RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT btrim(regexp_replace(lower(unaccent(p)), '[^a-z0-9]+', '_', 'g'), '_')
$$;

-- Applique f_norm_key à toutes les clés d'un objet JSON (en-têtes CSV hétérogènes)
CREATE OR REPLACE FUNCTION silver.f_norm_keys(p jsonb) RETURNS jsonb
LANGUAGE sql STABLE AS $$
  SELECT COALESCE(jsonb_object_agg(silver.f_norm_key(k), v), '{}'::jsonb)
  FROM jsonb_each(p) AS e(k, v)
$$;

-- Nom normalisé pour les rapprochements (accents, casse, ponctuation)
CREATE OR REPLACE FUNCTION silver.f_norm_name(p text) RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(btrim(regexp_replace(lower(unaccent(coalesce(p,''))), '[^a-z0-9]+', ' ', 'g')), '')
$$;

-- ---------------------------------------------------------------------
-- 3. Extraction de la charge utile (payload) d'une ligne Bronze
--    Flux S3 (API/CSV) : la destination S3 "No flattening" range la donnée
--    métier dans _airbyte_data ; si l'équipe a choisi "Root level flattening",
--    la donnée est à la racine. On gère les deux cas.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION silver.f_payload(rec jsonb) RETURNS jsonb
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF jsonb_typeof(rec->'_airbyte_data') = 'object' THEN
    RETURN rec->'_airbyte_data';
  ELSIF jsonb_typeof(rec->'_airbyte_data') = 'string' THEN
    RETURN (rec->>'_airbyte_data')::jsonb;
  END IF;
  RETURN rec;
EXCEPTION WHEN others THEN RETURN rec;
END $$;

-- ---------------------------------------------------------------------
-- 4. Création des vues de staging (stg_*) au-dessus de Bronze.
--    Une vue = une table Bronze, colonnes homogènes :
--      bronze_table, bronze_raw_id, bronze_extracted_at, source_file,
--      source_file_modified, payload (jsonb)
--    Table absente : erreur si p_required, sinon vue vide (flux optionnel).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION silver.f_create_stg_view(p_view text, p_table text, p_required boolean DEFAULT true)
RETURNS text LANGUAGE plpgsql AS $$
BEGIN
  IF to_regclass(format('bronze.%I', p_table)) IS NOT NULL THEN
    EXECUTE format($v$
      CREATE OR REPLACE VIEW silver.%I AS
      SELECT %L::text                                                   AS bronze_table,
             (to_jsonb(b)->>'_airbyte_raw_id')                          AS bronze_raw_id,
             silver.f_to_ts(to_jsonb(b)->>'_airbyte_extracted_at')      AS bronze_extracted_at,
             (to_jsonb(b)->>'_ab_source_file_url')                      AS source_file,
             silver.f_to_ts(to_jsonb(b)->>'_ab_source_file_last_modified') AS source_file_modified,
             silver.f_payload(to_jsonb(b))                              AS payload
      FROM bronze.%I b $v$, p_view, 'bronze.' || p_table, p_table);
    RETURN format('OK   silver.%s <- bronze.%s', p_view, p_table);
  ELSIF p_required THEN
    RAISE EXCEPTION 'Table Bronze manquante : bronze.% (lancez la synchronisation Airbyte correspondante)', p_table;
  ELSE
    EXECUTE format($v$
      CREATE OR REPLACE VIEW silver.%I AS
      SELECT NULL::text AS bronze_table, NULL::text AS bronze_raw_id, NULL::timestamptz AS bronze_extracted_at,
             NULL::text AS source_file, NULL::timestamptz AS source_file_modified, NULL::jsonb AS payload
      WHERE false $v$, p_view);
    RETURN format('VIDE silver.%s (bronze.%s absente, flux optionnel)', p_view, p_table);
  END IF;
END $$;

-- ---------------------------------------------------------------------
-- 5. Tables techniques (conservées d'un run à l'autre)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS silver.etl_run_log (
  run_id       bigserial PRIMARY KEY,
  started_at   timestamptz NOT NULL DEFAULT clock_timestamp(),
  finished_at  timestamptz,
  status       text NOT NULL DEFAULT 'RUNNING' CHECK (status IN ('RUNNING','SUCCESS','FAILED')),
  triggered_by text NOT NULL DEFAULT current_user,
  git_version  text,
  comment      text
);

CREATE TABLE IF NOT EXISTS silver.dq_results (
  run_id      bigint      NOT NULL REFERENCES silver.etl_run_log(run_id),
  checked_at  timestamptz NOT NULL DEFAULT clock_timestamp(),
  category    text        NOT NULL,   -- STRUCTURE, TYPES, UNICITE, DOUBLONS, VOLUMES, TRACABILITE, INTEGRITE, DOMAINE, FRAICHEUR
  test_name   text        NOT NULL,
  table_name  text        NOT NULL,
  severity    text        NOT NULL CHECK (severity IN ('BLOQUANT','AVERTISSEMENT')),
  status      text        NOT NULL CHECK (status IN ('OK','KO')),
  observed    numeric,
  expected    text,
  details     text,
  PRIMARY KEY (run_id, test_name, table_name)
);

-- Comptage dynamique d'une table (NULL si absente)
CREATE OR REPLACE FUNCTION silver.f_count(p_regclass text) RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE n bigint;
BEGIN
  IF to_regclass(p_regclass) IS NULL THEN RETURN NULL; END IF;
  EXECUTE format('SELECT count(*) FROM %s', p_regclass) INTO n;
  RETURN n;
END $$;

-- Lève une erreur (utilisable dans un SELECT, pour stopper psql avec ON_ERROR_STOP)
CREATE OR REPLACE FUNCTION silver.f_raise(p_msg text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '%', p_msg; END $$;

-- Helper d'enregistrement d'un contrôle
CREATE OR REPLACE FUNCTION silver.f_dq(p_run bigint, p_cat text, p_test text, p_table text,
                                       p_sev text, p_ok boolean, p_obs numeric, p_exp text, p_details text DEFAULT NULL)
RETURNS void LANGUAGE sql AS $$
  INSERT INTO silver.dq_results(run_id, category, test_name, table_name, severity, status, observed, expected, details)
  VALUES (p_run, p_cat, p_test, p_table, p_sev, CASE WHEN p_ok THEN 'OK' ELSE 'KO' END, p_obs, p_exp, p_details)
  ON CONFLICT (run_id, test_name, table_name) DO UPDATE
    SET status = EXCLUDED.status, observed = EXCLUDED.observed, details = EXCLUDED.details, checked_at = clock_timestamp();
$$;

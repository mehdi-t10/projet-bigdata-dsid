-- =====================================================================
-- sql/silver/30_crm.sql — Flux 3 (EspoCRM / MariaDB) : Bronze -> Silver
-- Tables : crm_account, crm_contact, crm_opportunity
-- Règles : dernière version par id (modified_at), exclusion des suppressions
--          logiques (deleted = 1), e-mail principal normalisé, téléphone principal,
--          libellés d'étape, montants/probabilités typés, champs personnalisés
--          optionnels c_cnc_id (compte) et c_tmdb_id (opportunité).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Vues "dernière version" (dédoublonnage AVANT filtrage des supprimés)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW silver.stg_crm_account_last AS
SELECT DISTINCT ON (payload->>'id') *
FROM silver.stg_crm_account
WHERE payload->>'id' IS NOT NULL
ORDER BY payload->>'id', silver.f_to_ts(payload->>'modified_at') DESC NULLS LAST, bronze_extracted_at DESC, bronze_raw_id DESC;

CREATE OR REPLACE VIEW silver.stg_crm_contact_last AS
SELECT DISTINCT ON (payload->>'id') *
FROM silver.stg_crm_contact
WHERE payload->>'id' IS NOT NULL
ORDER BY payload->>'id', silver.f_to_ts(payload->>'modified_at') DESC NULLS LAST, bronze_extracted_at DESC, bronze_raw_id DESC;

CREATE OR REPLACE VIEW silver.stg_crm_opportunity_last AS
SELECT DISTINCT ON (payload->>'id') *
FROM silver.stg_crm_opportunity
WHERE payload->>'id' IS NOT NULL
ORDER BY payload->>'id', silver.f_to_ts(payload->>'modified_at') DESC NULLS LAST, bronze_extracted_at DESC, bronze_raw_id DESC;

-- E-mail principal par entité (tables de liaison EspoCRM)
CREATE OR REPLACE VIEW silver.stg_crm_primary_email AS
SELECT DISTINCT ON (l.payload->>'entity_type', l.payload->>'entity_id')
       l.payload->>'entity_type'                   AS entity_type,
       l.payload->>'entity_id'                     AS entity_id,
       lower(btrim(e.payload->>'name'))            AS email,
       COALESCE(silver.f_to_bool(e.payload->>'invalid'), false) AS email_invalid,
       COALESCE(silver.f_to_bool(e.payload->>'opt_out'), false) AS email_opt_out
FROM silver.stg_crm_entity_email_address l
JOIN silver.stg_crm_email_address e ON e.payload->>'id' = l.payload->>'email_address_id'
WHERE NOT COALESCE(silver.f_to_bool(l.payload->>'deleted'), false)
  AND NOT COALESCE(silver.f_to_bool(e.payload->>'deleted'), false)
ORDER BY l.payload->>'entity_type', l.payload->>'entity_id',
         COALESCE(silver.f_to_bool(l.payload->>'primary'), false) DESC, l.bronze_extracted_at DESC;

CREATE OR REPLACE VIEW silver.stg_crm_primary_phone AS
SELECT DISTINCT ON (l.payload->>'entity_type', l.payload->>'entity_id')
       l.payload->>'entity_type' AS entity_type,
       l.payload->>'entity_id'   AS entity_id,
       silver.f_clean_text(p.payload->>'name') AS phone,
       silver.f_clean_text(p.payload->>'type') AS phone_type
FROM silver.stg_crm_entity_phone_number l
JOIN silver.stg_crm_phone_number p ON p.payload->>'id' = l.payload->>'phone_number_id'
WHERE NOT COALESCE(silver.f_to_bool(l.payload->>'deleted'), false)
  AND NOT COALESCE(silver.f_to_bool(p.payload->>'deleted'), false)
ORDER BY l.payload->>'entity_type', l.payload->>'entity_id',
         COALESCE(silver.f_to_bool(l.payload->>'primary'), false) DESC, l.bronze_extracted_at DESC;

-- ---------------------------------------------------------------------
-- silver.crm_account
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.crm_account CASCADE;
CREATE TABLE silver.crm_account (
  account_id        varchar(64)  PRIMARY KEY,
  account_name      text         NOT NULL,
  account_name_norm text,
  account_type      text,
  industry          text,
  website           text,
  email             text,
  phone             text,
  billing_street    text,
  billing_city      text,
  billing_postal_code varchar(10),
  billing_country   text,
  cnc_cinema_id     text,                         -- champ perso EspoCRM "cCncId" (optionnel)
  created_at        timestamptz,
  modified_at       timestamptz,
  bronze_raw_id     text         NOT NULL,
  bronze_extracted_at timestamptz NOT NULL,
  silver_loaded_at  timestamptz  NOT NULL DEFAULT now()
);

INSERT INTO silver.crm_account
SELECT a.payload->>'id',
       COALESCE(silver.f_clean_text(a.payload->>'name'), '(sans nom)'),
       silver.f_norm_name(a.payload->>'name'),
       silver.f_clean_text(a.payload->>'type'),
       silver.f_clean_text(a.payload->>'industry'),
       lower(silver.f_clean_text(a.payload->>'website')),
       em.email,
       ph.phone,
       silver.f_clean_text(a.payload->>'billing_address_street'),
       initcap(lower(silver.f_clean_text(a.payload->>'billing_address_city'))),
       replace(silver.f_clean_text(a.payload->>'billing_address_postal_code'), ' ', ''),
       silver.f_clean_text(a.payload->>'billing_address_country'),
       silver.f_clean_text(COALESCE(a.payload->>'c_cnc_id', a.payload->>'cnc_id')),
       silver.f_to_ts(a.payload->>'created_at'),
       silver.f_to_ts(a.payload->>'modified_at'),
       a.bronze_raw_id, a.bronze_extracted_at
FROM silver.stg_crm_account_last a
LEFT JOIN silver.stg_crm_primary_email em ON em.entity_type = 'Account' AND em.entity_id = a.payload->>'id'
LEFT JOIN silver.stg_crm_primary_phone ph ON ph.entity_type = 'Account' AND ph.entity_id = a.payload->>'id'
WHERE NOT COALESCE(silver.f_to_bool(a.payload->>'deleted'), false);

-- ---------------------------------------------------------------------
-- silver.crm_contact
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.crm_contact CASCADE;
CREATE TABLE silver.crm_contact (
  contact_id        varchar(64)  PRIMARY KEY,
  salutation        text,
  first_name        text,
  last_name         text         NOT NULL,
  full_name         text         NOT NULL,
  email             text,
  email_is_valid    boolean,
  email_opt_out     boolean,
  phone             text,
  account_id        varchar(64),
  city              text,
  postal_code       varchar(10),
  created_at        timestamptz,
  modified_at       timestamptz,
  bronze_raw_id     text         NOT NULL,
  bronze_extracted_at timestamptz NOT NULL,
  silver_loaded_at  timestamptz  NOT NULL DEFAULT now()
);

INSERT INTO silver.crm_contact
SELECT c.payload->>'id',
       silver.f_clean_text(c.payload->>'salutation_name'),
       initcap(lower(silver.f_clean_text(c.payload->>'first_name'))),
       upper(COALESCE(silver.f_clean_text(c.payload->>'last_name'), '(inconnu)')),
       concat_ws(' ', initcap(lower(silver.f_clean_text(c.payload->>'first_name'))),
                      upper(COALESCE(silver.f_clean_text(c.payload->>'last_name'), '(inconnu)'))),
       em.email,
       CASE WHEN em.email IS NULL THEN NULL
            ELSE em.email ~ '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$' AND NOT em.email_invalid END,
       em.email_opt_out,
       ph.phone,
       NULLIF(c.payload->>'account_id', ''),
       initcap(lower(silver.f_clean_text(c.payload->>'address_city'))),
       replace(silver.f_clean_text(c.payload->>'address_postal_code'), ' ', ''),
       silver.f_to_ts(c.payload->>'created_at'),
       silver.f_to_ts(c.payload->>'modified_at'),
       c.bronze_raw_id, c.bronze_extracted_at
FROM silver.stg_crm_contact_last c
LEFT JOIN silver.stg_crm_primary_email em ON em.entity_type = 'Contact' AND em.entity_id = c.payload->>'id'
LEFT JOIN silver.stg_crm_primary_phone ph ON ph.entity_type = 'Contact' AND ph.entity_id = c.payload->>'id'
WHERE NOT COALESCE(silver.f_to_bool(c.payload->>'deleted'), false);

-- ---------------------------------------------------------------------
-- silver.crm_opportunity
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.crm_opportunity CASCADE;
CREATE TABLE silver.crm_opportunity (
  opportunity_id    varchar(64)  PRIMARY KEY,
  opportunity_name  text         NOT NULL,
  account_id        varchar(64),
  contact_id        varchar(64),
  stage             text,
  stage_fr          text,
  is_closed         boolean      NOT NULL,
  is_won            boolean      NOT NULL,
  amount            numeric(14,2),
  currency          char(3),
  probability_pct   smallint,
  weighted_amount   numeric(14,2),
  close_date        date,
  lead_source       text,
  tmdb_film_id      integer,                       -- champ perso EspoCRM "cTmdbId" (optionnel)
  created_at        timestamptz,
  modified_at       timestamptz,
  bronze_raw_id     text         NOT NULL,
  bronze_extracted_at timestamptz NOT NULL,
  silver_loaded_at  timestamptz  NOT NULL DEFAULT now()
);

INSERT INTO silver.crm_opportunity
SELECT o.payload->>'id',
       COALESCE(silver.f_clean_text(o.payload->>'name'), '(sans nom)'),
       NULLIF(o.payload->>'account_id', ''),
       NULLIF(o.payload->>'contact_id', ''),
       silver.f_clean_text(o.payload->>'stage'),
       CASE silver.f_clean_text(o.payload->>'stage')
         WHEN 'Prospecting'   THEN 'Prospection'
         WHEN 'Qualification' THEN 'Qualification'
         WHEN 'Proposal'      THEN 'Proposition'
         WHEN 'Negotiation'   THEN 'Négociation'
         WHEN 'Closed Won'    THEN 'Gagnée'
         WHEN 'Closed Lost'   THEN 'Perdue'
         ELSE silver.f_clean_text(o.payload->>'stage') END,
       COALESCE(silver.f_clean_text(o.payload->>'stage') IN ('Closed Won','Closed Lost'), false),
       COALESCE(silver.f_clean_text(o.payload->>'stage') = 'Closed Won', false),
       round(silver.f_to_num(o.payload->>'amount'), 2),
       upper(NULLIF(left(o.payload->>'amount_currency', 3), '')),
       silver.f_to_int(o.payload->>'probability')::smallint,
       round(silver.f_to_num(o.payload->>'amount') * COALESCE(silver.f_to_num(o.payload->>'probability'), 0) / 100, 2),
       silver.f_to_date(o.payload->>'close_date'),
       silver.f_clean_text(o.payload->>'lead_source'),
       silver.f_to_int(COALESCE(o.payload->>'c_tmdb_id', o.payload->>'tmdb_id'))::int,
       silver.f_to_ts(o.payload->>'created_at'),
       silver.f_to_ts(o.payload->>'modified_at'),
       o.bronze_raw_id, o.bronze_extracted_at
FROM silver.stg_crm_opportunity_last o
WHERE NOT COALESCE(silver.f_to_bool(o.payload->>'deleted'), false);

CREATE INDEX IF NOT EXISTS ix_crm_contact_account ON silver.crm_contact(account_id);
CREATE INDEX IF NOT EXISTS ix_crm_opp_account     ON silver.crm_opportunity(account_id);
COMMENT ON TABLE silver.crm_opportunity IS 'Opportunités EspoCRM (dernière version, hors supprimées), montants typés et pondérés';

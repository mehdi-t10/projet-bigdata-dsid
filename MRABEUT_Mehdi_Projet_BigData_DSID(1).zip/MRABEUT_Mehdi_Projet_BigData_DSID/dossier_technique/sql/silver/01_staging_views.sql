-- =====================================================================
-- sql/silver/01_staging_views.sql
-- Vues de staging : une par table Bronze, interface homogène pour Silver.
-- Si vos noms de tables Bronze diffèrent, c'est le SEUL fichier à adapter.
-- =====================================================================

-- Flux 1 : API TMDB  (Airbyte TMDB -> MinIO raw/api/tmdb -> Airbyte S3 -> bronze)
SELECT silver.f_create_stg_view('stg_tmdb_genres',             'tmdb_genres',             true);
SELECT silver.f_create_stg_view('stg_tmdb_movies_now_playing', 'tmdb_movies_now_playing', true);
SELECT silver.f_create_stg_view('stg_tmdb_movies_popular',     'tmdb_movies_popular',     true);
SELECT silver.f_create_stg_view('stg_tmdb_trending_week',      'tmdb_trending_week',      false);
SELECT silver.f_create_stg_view('stg_tmdb_movie_details',      'tmdb_movie_details',      true);

-- Flux 2 : CSV cinémas Île-de-France (Airbyte File -> MinIO raw/csv -> Airbyte S3 -> bronze)
SELECT silver.f_create_stg_view('stg_csv_cinemas_idf',         'csv_cinemas_idf',         true);

-- Flux 3 : EspoCRM (MariaDB -> Airbyte MySQL source -> bronze, préfixe crm_)
SELECT silver.f_create_stg_view('stg_crm_account',              'crm_account',              true);
SELECT silver.f_create_stg_view('stg_crm_contact',              'crm_contact',              true);
SELECT silver.f_create_stg_view('stg_crm_opportunity',          'crm_opportunity',          true);
SELECT silver.f_create_stg_view('stg_crm_email_address',        'crm_email_address',        false);
SELECT silver.f_create_stg_view('stg_crm_entity_email_address', 'crm_entity_email_address', false);
SELECT silver.f_create_stg_view('stg_crm_phone_number',         'crm_phone_number',         false);
SELECT silver.f_create_stg_view('stg_crm_entity_phone_number',  'crm_entity_phone_number',  false);

-- Vue d'union des 3 listes de films TMDB (même structure)
CREATE OR REPLACE VIEW silver.stg_tmdb_movie_lists AS
SELECT 'now_playing'::text AS list_type, * FROM silver.stg_tmdb_movies_now_playing
UNION ALL
SELECT 'popular',                        * FROM silver.stg_tmdb_movies_popular
UNION ALL
SELECT 'trending_week',                  * FROM silver.stg_tmdb_trending_week;

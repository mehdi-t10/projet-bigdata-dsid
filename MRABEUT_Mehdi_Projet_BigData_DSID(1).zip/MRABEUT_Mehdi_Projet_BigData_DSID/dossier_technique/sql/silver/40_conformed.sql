-- =====================================================================
-- sql/silver/40_conformed.sql — Rapprochement des 3 flux
--   CRM (comptes = cinémas clients)  <->  CSV CNC (cinémas IDF)
--   CRM (opportunités = programmation d'un film) <-> API TMDB (films)
-- =====================================================================

-- ---------------------------------------------------------------------
-- silver.crm_account_cinema_link : compte CRM -> établissement CNC
--   1) correspondance exacte par champ perso c_cnc_id (confiance 1.0)
--   2) sinon nom normalisé + ville identiques (confiance 0.8)
--   3) sinon nom normalisé seul, si unique en IDF (confiance 0.5)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS silver.crm_account_cinema_link CASCADE;
CREATE TABLE silver.crm_account_cinema_link (
  account_id     varchar(64) PRIMARY KEY REFERENCES silver.crm_account(account_id),
  cinema_id      text        NOT NULL REFERENCES silver.cinema_idf(cinema_id),
  match_method   text        NOT NULL CHECK (match_method IN ('cnc_id','nom_ville','nom_unique')),
  confidence     numeric(3,2) NOT NULL
);

INSERT INTO silver.crm_account_cinema_link
SELECT DISTINCT ON (account_id) account_id, cinema_id, match_method, confidence
FROM (
  SELECT a.account_id, c.cinema_id, 'cnc_id' AS match_method, 1.00 AS confidence
  FROM silver.crm_account a JOIN silver.cinema_idf c ON c.cinema_id = a.cnc_cinema_id
  UNION ALL
  SELECT a.account_id, c.cinema_id, 'nom_ville', 0.80
  FROM silver.crm_account a
  JOIN silver.cinema_idf c
    ON c.cinema_name_norm = a.account_name_norm
   AND silver.f_norm_name(c.commune) = silver.f_norm_name(a.billing_city)
  UNION ALL
  SELECT a.account_id, c.cinema_id, 'nom_unique', 0.50
  FROM silver.crm_account a
  JOIN silver.cinema_idf c ON c.cinema_name_norm = a.account_name_norm
  WHERE (SELECT count(*) FROM silver.cinema_idf c2 WHERE c2.cinema_name_norm = a.account_name_norm) = 1
) m
ORDER BY account_id, confidence DESC;

-- ---------------------------------------------------------------------
-- Vue 360° des opportunités : CRM + cinéma CNC + film TMDB
-- (vue Silver "conformée", base pour une future couche Gold)
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW silver.v_opportunity_360 AS
SELECT o.opportunity_id, o.opportunity_name, o.stage_fr, o.is_won, o.amount, o.weighted_amount, o.close_date,
       a.account_id, a.account_name,
       ct.full_name           AS contact_name, ct.email AS contact_email,
       l.cinema_id, l.match_method, ci.commune, ci.departement, ci.nb_ecrans, ci.nb_fauteuils, ci.entrees,
       f.film_id, f.title     AS film_title, f.release_date, f.popularity, f.vote_average, f.in_now_playing
FROM silver.crm_opportunity o
LEFT JOIN silver.crm_account a               ON a.account_id = o.account_id
LEFT JOIN silver.crm_contact ct              ON ct.contact_id = o.contact_id
LEFT JOIN silver.crm_account_cinema_link l   ON l.account_id = o.account_id
LEFT JOIN silver.cinema_idf ci               ON ci.cinema_id = l.cinema_id
LEFT JOIN silver.tmdb_film f                 ON f.film_id = o.tmdb_film_id;

COMMENT ON VIEW silver.v_opportunity_360 IS 'Opportunités enrichies : compte/contact CRM + établissement CNC + film TMDB';

-- =====================================================================
-- sql/tests/10_dq_silver.sql — Contrôles qualité APRÈS construction Silver
-- Variable psql : :run_id   — Résultats : silver.dq_results
-- Catégories : STRUCTURE, TYPES, UNICITE, DOUBLONS, VOLUMES, TRACABILITE,
--              INTEGRITE, DOMAINE, FRAICHEUR
-- Sévérité : BLOQUANT (le run échoue) / AVERTISSEMENT (signalé, run OK)
-- =====================================================================

-- =====================================================================
-- 1. STRUCTURE — colonnes attendues ET types attendus
-- =====================================================================
WITH expected(tbl, col, typ) AS (VALUES
  ('tmdb_genre','genre_id','integer'), ('tmdb_genre','genre_name','text'),
  ('tmdb_film','film_id','integer'), ('tmdb_film','title','text'), ('tmdb_film','release_date','date'),
  ('tmdb_film','vote_average','numeric'), ('tmdb_film','vote_count','integer'), ('tmdb_film','runtime_min','integer'),
  ('tmdb_film','budget_usd','bigint'), ('tmdb_film','bronze_raw_id','text'), ('tmdb_film','last_seen_at','timestamp with time zone'),
  ('tmdb_film_genre','film_id','integer'), ('tmdb_film_genre','genre_id','integer'),
  ('tmdb_film_list_snapshot','snapshot_date','date'), ('tmdb_film_list_snapshot','popularity','numeric'),
  ('cinema_idf','cinema_id','text'), ('cinema_idf','code_insee','character'), ('cinema_idf','departement','character'),
  ('cinema_idf','nb_ecrans','integer'), ('cinema_idf','nb_fauteuils','integer'), ('cinema_idf','entrees','bigint'),
  ('cinema_idf','latitude','numeric'), ('cinema_idf','is_art_et_essai','boolean'), ('cinema_idf','bronze_raw_id','text'),
  ('crm_account','account_id','character varying'), ('crm_account','account_name','text'), ('crm_account','modified_at','timestamp with time zone'),
  ('crm_contact','contact_id','character varying'), ('crm_contact','email','text'), ('crm_contact','account_id','character varying'),
  ('crm_opportunity','opportunity_id','character varying'), ('crm_opportunity','amount','numeric'),
  ('crm_opportunity','probability_pct','smallint'), ('crm_opportunity','close_date','date'), ('crm_opportunity','is_won','boolean')
)
SELECT silver.f_dq(:run_id, 'STRUCTURE', 'colonnes_et_types_attendus', 'silver.' || e.tbl, 'BLOQUANT',
                   count(*) FILTER (WHERE c.data_type IS DISTINCT FROM e.typ) = 0,
                   count(*) FILTER (WHERE c.data_type IS DISTINCT FROM e.typ), '0 écart',
                   string_agg(CASE WHEN c.data_type IS DISTINCT FROM e.typ
                                   THEN e.col || ' attendu ' || e.typ || ' obtenu ' || COALESCE(c.data_type, 'ABSENT') END, '; '))
FROM expected e
LEFT JOIN information_schema.columns c
  ON c.table_schema = 'silver' AND c.table_name = e.tbl AND c.column_name = e.col
GROUP BY e.tbl;

-- Clé primaire déclarée sur chaque table Silver métier
SELECT silver.f_dq(:run_id, 'STRUCTURE', 'cle_primaire_declaree', 'silver.' || t.table_name, 'BLOQUANT',
                   tc.constraint_name IS NOT NULL, (tc.constraint_name IS NOT NULL)::int, '1')
FROM information_schema.tables t
LEFT JOIN information_schema.table_constraints tc
  ON tc.table_schema = t.table_schema AND tc.table_name = t.table_name AND tc.constraint_type = 'PRIMARY KEY'
WHERE t.table_schema = 'silver' AND t.table_type = 'BASE TABLE'
  AND t.table_name NOT IN ('etl_run_log', 'dq_results');

-- =====================================================================
-- 2. TYPES — valeurs présentes en Bronze mais non convertibles en Silver
--    (le cast "sûr" a renvoyé NULL) => perte d'information à surveiller
-- =====================================================================
SELECT silver.f_dq(:run_id, 'TYPES', 'release_date_convertible', 'silver.tmdb_film', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', 'release_date non vide mais non convertible en date')
FROM silver.stg_tmdb_movie_lists
WHERE NULLIF(payload->>'release_date', '') IS NOT NULL AND silver.f_to_date(payload->>'release_date') IS NULL;

SELECT silver.f_dq(:run_id, 'TYPES', 'vote_average_numerique', 'silver.tmdb_film', 'BLOQUANT',
                   count(*) = 0, count(*), '0')
FROM silver.stg_tmdb_movie_lists
WHERE payload->>'vote_average' IS NOT NULL AND silver.f_to_num(payload->>'vote_average') IS NULL;

SELECT silver.f_dq(:run_id, 'TYPES', 'ecrans_fauteuils_entiers', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', 'écrans/fauteuils présents mais non entiers')
FROM (SELECT silver.f_norm_keys(payload) j FROM silver.stg_csv_cinemas_idf) s
WHERE (silver.f_clean_text(j->>'ecrans') IS NOT NULL AND silver.f_to_int(j->>'ecrans') IS NULL)
   OR (silver.f_clean_text(j->>'fauteuils') IS NOT NULL AND silver.f_to_int(j->>'fauteuils') IS NULL);

SELECT silver.f_dq(:run_id, 'TYPES', 'montant_numerique', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = 0, count(*), '0')
FROM silver.stg_crm_opportunity_last
WHERE NULLIF(payload->>'amount', '') IS NOT NULL AND silver.f_to_num(payload->>'amount') IS NULL;

SELECT silver.f_dq(:run_id, 'TYPES', 'close_date_convertible', 'silver.crm_opportunity', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0')
FROM silver.stg_crm_opportunity_last
WHERE NULLIF(payload->>'close_date', '') IS NOT NULL AND silver.f_to_date(payload->>'close_date') IS NULL;

-- =====================================================================
-- 3. UNICITE — clés métier uniques dans Silver
-- =====================================================================
SELECT silver.f_dq(:run_id, 'UNICITE', 'film_id_unique', 'silver.tmdb_film', 'BLOQUANT',
                   count(*) = count(DISTINCT film_id), count(*) - count(DISTINCT film_id), '0 doublon')
FROM silver.tmdb_film;
SELECT silver.f_dq(:run_id, 'UNICITE', 'genre_id_unique', 'silver.tmdb_genre', 'BLOQUANT',
                   count(*) = count(DISTINCT genre_id), count(*) - count(DISTINCT genre_id), '0 doublon')
FROM silver.tmdb_genre;
SELECT silver.f_dq(:run_id, 'UNICITE', 'cinema_id_unique', 'silver.cinema_idf', 'BLOQUANT',
                   count(*) = count(DISTINCT cinema_id), count(*) - count(DISTINCT cinema_id), '0 doublon')
FROM silver.cinema_idf;
SELECT silver.f_dq(:run_id, 'UNICITE', 'account_id_unique', 'silver.crm_account', 'BLOQUANT',
                   count(*) = count(DISTINCT account_id), count(*) - count(DISTINCT account_id), '0 doublon')
FROM silver.crm_account;
SELECT silver.f_dq(:run_id, 'UNICITE', 'contact_id_unique', 'silver.crm_contact', 'BLOQUANT',
                   count(*) = count(DISTINCT contact_id), count(*) - count(DISTINCT contact_id), '0 doublon')
FROM silver.crm_contact;
SELECT silver.f_dq(:run_id, 'UNICITE', 'opportunity_id_unique', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = count(DISTINCT opportunity_id), count(*) - count(DISTINCT opportunity_id), '0 doublon')
FROM silver.crm_opportunity;

-- Unicité "métier" secondaire (avertissement) : même e-mail pour 2 contacts
SELECT silver.f_dq(:run_id, 'UNICITE', 'email_contact_unique', 'silver.crm_contact', 'AVERTISSEMENT',
                   COALESCE(sum(n - 1), 0) = 0, COALESCE(sum(n - 1), 0), '0',
                   string_agg(email, ', '))
FROM (SELECT email, count(*) n FROM silver.crm_contact WHERE email IS NOT NULL GROUP BY email HAVING count(*) > 1) d;

-- =====================================================================
-- 4. DOUBLONS — mesure des doublons Bronze éliminés (information) et
--    doublons "probables" restants (même nom + même commune)
-- =====================================================================
SELECT silver.f_dq(:run_id, 'DOUBLONS', 'doublons_bronze_films_elimines', 'silver.tmdb_film', 'AVERTISSEMENT',
                   true, count(*) - count(DISTINCT payload->>'id'), 'information',
                   'lignes Bronze (listes) en double fusionnées par le dédoublonnage')
FROM silver.stg_tmdb_movie_lists;

SELECT silver.f_dq(:run_id, 'DOUBLONS', 'doublons_bronze_cinemas_elimines', 'silver.cinema_idf', 'AVERTISSEMENT',
                   true, (SELECT count(*) FROM silver.stg_csv_cinemas_idf) - (SELECT count(*) FROM silver.cinema_idf),
                   'information', 'lignes CSV en double (ré-ingestion) ou sans nom écartées');

SELECT silver.f_dq(:run_id, 'DOUBLONS', 'doublons_bronze_crm_versions', 'silver.crm_contact', 'AVERTISSEMENT',
                   true, (SELECT count(*) FROM silver.stg_crm_contact) - (SELECT count(*) FROM silver.stg_crm_contact_last),
                   'information', 'anciennes versions de contacts (sync incrémentale append) écartées');

SELECT silver.f_dq(:run_id, 'DOUBLONS', 'cinema_meme_nom_meme_commune', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', string_agg(cinema_name || ' (' || commune || ')', ', '))
FROM (SELECT cinema_name_norm, commune, min(cinema_name) cinema_name
      FROM silver.cinema_idf GROUP BY 1, 2 HAVING count(*) > 1) d;

SELECT silver.f_dq(:run_id, 'DOUBLONS', 'contact_meme_nom_meme_compte', 'silver.crm_contact', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', string_agg(full_name, ', '))
FROM (SELECT full_name, account_id FROM silver.crm_contact GROUP BY 1, 2 HAVING count(*) > 1) d;

-- =====================================================================
-- 5. VOLUMES — Silver non vide, cohérence Bronze -> Silver
-- =====================================================================
SELECT silver.f_dq(:run_id, 'VOLUMES', 'silver_non_vide', 'silver.' || t, 'BLOQUANT',
                   silver.f_count('silver.' || t) > 0, silver.f_count('silver.' || t), '> 0')
FROM unnest(ARRAY['tmdb_genre','tmdb_film','tmdb_film_genre','cinema_idf','crm_account','crm_contact','crm_opportunity']) t;

-- Films Silver = ids distincts Bronze (listes ∪ détails) : aucune perte, aucun ajout
SELECT silver.f_dq(:run_id, 'VOLUMES', 'films_bronze_egal_silver', 'silver.tmdb_film', 'BLOQUANT',
                   b.n = s.n, s.n, b.n::text || ' (ids distincts Bronze)')
FROM (SELECT count(DISTINCT silver.f_to_int(payload->>'id')) n FROM (
        SELECT payload FROM silver.stg_tmdb_movie_lists UNION ALL SELECT payload FROM silver.stg_tmdb_movie_details) x
      WHERE silver.f_to_int(payload->>'id') IS NOT NULL) b,
     (SELECT count(*) n FROM silver.tmdb_film) s;

-- Contacts Silver = ids distincts Bronze non supprimés (dernière version)
SELECT silver.f_dq(:run_id, 'VOLUMES', 'contacts_bronze_egal_silver', 'silver.crm_contact', 'BLOQUANT',
                   b.n = s.n, s.n, b.n::text || ' (contacts actifs Bronze)')
FROM (SELECT count(*) n FROM silver.stg_crm_contact_last WHERE NOT COALESCE(silver.f_to_bool(payload->>'deleted'), false)) b,
     (SELECT count(*) n FROM silver.crm_contact) s;

SELECT silver.f_dq(:run_id, 'VOLUMES', 'opportunites_bronze_egal_silver', 'silver.crm_opportunity', 'BLOQUANT',
                   b.n = s.n, s.n, b.n::text || ' (opportunités actives Bronze)')
FROM (SELECT count(*) n FROM silver.stg_crm_opportunity_last WHERE NOT COALESCE(silver.f_to_bool(payload->>'deleted'), false)) b,
     (SELECT count(*) n FROM silver.crm_opportunity) s;

-- Ordre de grandeur attendu (sources réelles) : ~19 genres TMDB, > 250 cinémas en IDF
SELECT silver.f_dq(:run_id, 'VOLUMES', 'ordre_grandeur_genres', 'silver.tmdb_genre', 'AVERTISSEMENT',
                   count(*) BETWEEN 15 AND 30, count(*), 'entre 15 et 30') FROM silver.tmdb_genre;
SELECT silver.f_dq(:run_id, 'VOLUMES', 'ordre_grandeur_cinemas_idf', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) >= 250, count(*), '>= 250') FROM silver.cinema_idf;

-- =====================================================================
-- 6. TRACABILITE — chaque ligne Silver pointe vers une ligne Bronze existante
-- =====================================================================
SELECT silver.f_dq(:run_id, 'TRACABILITE', 'bronze_raw_id_existe', 'silver.tmdb_film', 'BLOQUANT',
                   count(*) = 0, count(*), '0 orphelin')
FROM silver.tmdb_film s
WHERE NOT EXISTS (SELECT 1 FROM silver.stg_tmdb_movie_lists b WHERE b.bronze_raw_id = s.bronze_raw_id)
  AND NOT EXISTS (SELECT 1 FROM silver.stg_tmdb_movie_details b WHERE b.bronze_raw_id = s.bronze_raw_id);

SELECT silver.f_dq(:run_id, 'TRACABILITE', 'bronze_raw_id_existe', 'silver.cinema_idf', 'BLOQUANT',
                   count(*) = 0, count(*), '0 orphelin')
FROM silver.cinema_idf s
WHERE NOT EXISTS (SELECT 1 FROM silver.stg_csv_cinemas_idf b WHERE b.bronze_raw_id = s.bronze_raw_id);

SELECT silver.f_dq(:run_id, 'TRACABILITE', 'bronze_raw_id_existe', 'silver.crm_contact', 'BLOQUANT',
                   count(*) = 0, count(*), '0 orphelin')
FROM silver.crm_contact s
WHERE NOT EXISTS (SELECT 1 FROM silver.stg_crm_contact b WHERE b.bronze_raw_id = s.bronze_raw_id);

SELECT silver.f_dq(:run_id, 'TRACABILITE', 'bronze_raw_id_existe', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = 0, count(*), '0 orphelin')
FROM silver.crm_opportunity s
WHERE NOT EXISTS (SELECT 1 FROM silver.stg_crm_opportunity b WHERE b.bronze_raw_id = s.bronze_raw_id);

SELECT silver.f_dq(:run_id, 'TRACABILITE', 'fichier_minio_renseigne', 'silver.' || t, 'AVERTISSEMENT',
                   n = 0, n, '0 ligne sans source_file')
FROM (SELECT 'tmdb_film' t, count(*) FILTER (WHERE source_file IS NULL) n FROM silver.tmdb_film
      UNION ALL
      SELECT 'cinema_idf', count(*) FILTER (WHERE source_file IS NULL) FROM silver.cinema_idf) x;

-- =====================================================================
-- 7. INTEGRITE référentielle
-- =====================================================================
SELECT silver.f_dq(:run_id, 'INTEGRITE', 'contact_account_existe', 'silver.crm_contact', 'BLOQUANT',
                   count(*) = 0, count(*), '0', string_agg(contact_id, ', '))
FROM silver.crm_contact c
WHERE c.account_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM silver.crm_account a WHERE a.account_id = c.account_id);

SELECT silver.f_dq(:run_id, 'INTEGRITE', 'opportunite_account_existe', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = 0, count(*), '0', string_agg(opportunity_id, ', '))
FROM silver.crm_opportunity o
WHERE o.account_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM silver.crm_account a WHERE a.account_id = o.account_id);

SELECT silver.f_dq(:run_id, 'INTEGRITE', 'film_genre_connu', 'silver.tmdb_film_genre', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', 'genre_id absent du référentiel tmdb_genre')
FROM silver.tmdb_film_genre fg
WHERE NOT EXISTS (SELECT 1 FROM silver.tmdb_genre g WHERE g.genre_id = fg.genre_id);

SELECT silver.f_dq(:run_id, 'INTEGRITE', 'opportunite_film_tmdb_connu', 'silver.crm_opportunity', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', string_agg(opportunity_name || ' -> ' || tmdb_film_id, ', '))
FROM silver.crm_opportunity o
WHERE o.tmdb_film_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM silver.tmdb_film f WHERE f.film_id = o.tmdb_film_id);

SELECT silver.f_dq(:run_id, 'INTEGRITE', 'compte_rapproche_cinema', 'silver.crm_account', 'AVERTISSEMENT',
                   true, round(100.0 * count(l.account_id) / NULLIF(count(*), 0), 1), 'information (% comptes reliés à un cinéma CNC)')
FROM silver.crm_account a LEFT JOIN silver.crm_account_cinema_link l USING (account_id);

-- =====================================================================
-- 8. DOMAINE — valeurs plausibles
-- =====================================================================
SELECT silver.f_dq(:run_id, 'DOMAINE', 'vote_average_0_10', 'silver.tmdb_film', 'BLOQUANT',
                   count(*) = 0, count(*), '0 hors [0;10]')
FROM silver.tmdb_film WHERE vote_average NOT BETWEEN 0 AND 10;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'vote_count_positif', 'silver.tmdb_film', 'BLOQUANT',
                   count(*) = 0, count(*), '0 négatif')
FROM silver.tmdb_film WHERE vote_count < 0 OR popularity < 0;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'runtime_plausible', 'silver.tmdb_film', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0 hors ]0;600] min')
FROM silver.tmdb_film WHERE runtime_min NOT BETWEEN 1 AND 600;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'departement_ile_de_france', 'silver.cinema_idf', 'BLOQUANT',
                   count(*) = 0, count(*), '75,77,78,91,92,93,94,95', string_agg(DISTINCT departement, ','))
FROM silver.cinema_idf WHERE departement IS NULL OR departement NOT IN ('75','77','78','91','92','93','94','95');

SELECT silver.f_dq(:run_id, 'DOMAINE', 'code_insee_coherent_departement', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', 'code_insee ne commence pas par le département')
FROM silver.cinema_idf WHERE code_insee IS NOT NULL AND left(code_insee, 2) <> departement;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'coordonnees_dans_idf', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) = 0, count(*), 'lat 48.1-49.3 / lon 1.4-3.6')
FROM silver.cinema_idf
WHERE latitude IS NOT NULL AND (latitude NOT BETWEEN 48.1 AND 49.3 OR longitude NOT BETWEEN 1.4 AND 3.6);

SELECT silver.f_dq(:run_id, 'DOMAINE', 'fauteuils_ge_ecrans', 'silver.cinema_idf', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0 (fauteuils >= écrans > 0)')
FROM silver.cinema_idf WHERE nb_ecrans <= 0 OR nb_fauteuils < nb_ecrans;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'montant_positif', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = 0, count(*), '0 montant négatif')
FROM silver.crm_opportunity WHERE amount < 0;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'probabilite_0_100', 'silver.crm_opportunity', 'BLOQUANT',
                   count(*) = 0, count(*), '0 hors [0;100]')
FROM silver.crm_opportunity WHERE probability_pct NOT BETWEEN 0 AND 100;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'email_format_valide', 'silver.crm_contact', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0', string_agg(email, ', '))
FROM silver.crm_contact WHERE email IS NOT NULL AND NOT email_is_valid;

SELECT silver.f_dq(:run_id, 'DOMAINE', 'contact_joignable', 'silver.crm_contact', 'AVERTISSEMENT',
                   count(*) = 0, count(*), '0 contact sans e-mail ni téléphone', string_agg(full_name, ', '))
FROM silver.crm_contact WHERE email IS NULL AND phone IS NULL;

-- =====================================================================
-- 9. FRAICHEUR — dernière extraction récente
-- =====================================================================
SELECT silver.f_dq(:run_id, 'FRAICHEUR', 'extraction_moins_7_jours', 'silver.' || t, 'AVERTISSEMENT',
                   age_h <= 168, round(age_h, 1), '<= 168 h')
FROM (SELECT 'tmdb_film' t, extract(epoch FROM now() - max(last_seen_at)) / 3600 age_h FROM silver.tmdb_film
      UNION ALL SELECT 'cinema_idf', extract(epoch FROM now() - max(data_as_of)) / 3600 FROM silver.cinema_idf
      UNION ALL SELECT 'crm_contact', extract(epoch FROM now() - max(bronze_extracted_at)) / 3600 FROM silver.crm_contact) x;

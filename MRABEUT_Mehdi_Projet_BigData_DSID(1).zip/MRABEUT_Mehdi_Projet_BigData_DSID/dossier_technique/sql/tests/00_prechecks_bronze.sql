-- =====================================================================
-- sql/tests/00_prechecks_bronze.sql
-- Contrôles AVANT construction de Silver (sur Bronze) — variable psql :run_id
--   STRUCTURE   : tables Bronze présentes + colonnes techniques Airbyte
--   VOLUMES     : tables non vides
--   TRACABILITE : fichier source MinIO renseigné pour les flux S3
-- =====================================================================

WITH expected(tbl, required, via_s3) AS (VALUES
  ('tmdb_genres', true, true), ('tmdb_movies_now_playing', true, true), ('tmdb_movies_popular', true, true),
  ('tmdb_trending_week', false, true), ('tmdb_movie_details', true, true),
  ('csv_cinemas_idf', true, true),
  ('crm_account', true, false), ('crm_contact', true, false), ('crm_opportunity', true, false),
  ('crm_email_address', false, false), ('crm_entity_email_address', false, false)
)
SELECT silver.f_dq(:run_id, 'STRUCTURE', 'bronze_table_presente', 'bronze.' || tbl,
                   CASE WHEN required THEN 'BLOQUANT' ELSE 'AVERTISSEMENT' END,
                   to_regclass('bronze.' || tbl) IS NOT NULL,
                   (to_regclass('bronze.' || tbl) IS NOT NULL)::int, '1',
                   CASE WHEN to_regclass('bronze.' || tbl) IS NULL THEN 'Synchronisation Airbyte à lancer' END)
FROM expected;

-- Colonnes techniques Airbyte (Destinations V2) présentes dans chaque table bronze
SELECT silver.f_dq(:run_id, 'STRUCTURE', 'bronze_colonnes_airbyte', 'bronze.' || t.table_name, 'BLOQUANT',
                   count(c.column_name) = 2, count(c.column_name), '2 (_airbyte_raw_id, _airbyte_extracted_at)')
FROM information_schema.tables t
LEFT JOIN information_schema.columns c
  ON c.table_schema = t.table_schema AND c.table_name = t.table_name
 AND c.column_name IN ('_airbyte_raw_id', '_airbyte_extracted_at')
WHERE t.table_schema = 'bronze' AND t.table_type = 'BASE TABLE'
GROUP BY t.table_name;

-- Volumes Bronze > 0

SELECT silver.f_dq(:run_id, 'VOLUMES', 'bronze_non_vide', 'bronze.' || table_name, 'BLOQUANT',
                   silver.f_count('bronze.' || quote_ident(table_name)) > 0,
                   silver.f_count('bronze.' || quote_ident(table_name)), '> 0')
FROM information_schema.tables
WHERE table_schema = 'bronze' AND table_type = 'BASE TABLE'
  AND table_name ~ '^(tmdb_|csv_|crm_(account|contact|opportunity)$)';

-- Flux S3 : chaque ligne doit connaître son fichier MinIO d'origine
CREATE OR REPLACE FUNCTION silver.f_count_missing_file(p_table text) RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE n bigint;
BEGIN
  IF to_regclass('bronze.' || quote_ident(p_table)) IS NULL THEN RETURN NULL; END IF;
  EXECUTE format('SELECT count(*) FROM bronze.%I b WHERE to_jsonb(b)->>''_ab_source_file_url'' IS NULL', p_table) INTO n;
  RETURN n;
END $$;

SELECT silver.f_dq(:run_id, 'TRACABILITE', 'bronze_fichier_minio_renseigne', 'bronze.' || table_name, 'AVERTISSEMENT',
                   silver.f_count_missing_file(table_name) = 0,
                   silver.f_count_missing_file(table_name), '0 ligne sans _ab_source_file_url')
FROM information_schema.tables
WHERE table_schema = 'bronze' AND table_type = 'BASE TABLE' AND table_name ~ '^(tmdb_|csv_)';

-- Arrêt immédiat si un précontrôle BLOQUANT échoue
UPDATE silver.etl_run_log SET status = 'FAILED', finished_at = clock_timestamp(), comment = 'Précontrôles Bronze KO'
 WHERE run_id = :run_id
   AND EXISTS (SELECT 1 FROM silver.dq_results
               WHERE run_id = :run_id AND severity = 'BLOQUANT' AND status = 'KO');

SELECT silver.f_raise('Précontrôles Bronze en échec : ' || string_agg(format('%s / %s', test_name, table_name), ' | '))
FROM silver.dq_results
WHERE run_id = :run_id AND severity = 'BLOQUANT' AND status = 'KO'
HAVING count(*) > 0;

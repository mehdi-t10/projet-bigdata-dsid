-- =====================================================================
-- sql/tests/99_report.sql — Synthèse du run + statut final
-- =====================================================================
\echo
\echo '================ SYNTHÈSE DES CONTRÔLES (run courant) ================'
SELECT category, severity,
       count(*) FILTER (WHERE status = 'OK') AS ok,
       count(*) FILTER (WHERE status = 'KO') AS ko
FROM silver.dq_results WHERE run_id = :run_id
GROUP BY category, severity ORDER BY category, severity;

\echo '---------------- Contrôles en échec (KO) ----------------'
SELECT severity, category, test_name, table_name, observed, expected, left(details, 120) AS details
FROM silver.dq_results WHERE run_id = :run_id AND status = 'KO'
ORDER BY severity, category, table_name;

\echo '---------------- Volumes Silver ----------------'
SELECT 'tmdb_genre' AS table_silver, count(*) AS lignes FROM silver.tmdb_genre
UNION ALL SELECT 'tmdb_film', count(*) FROM silver.tmdb_film
UNION ALL SELECT 'tmdb_film_genre', count(*) FROM silver.tmdb_film_genre
UNION ALL SELECT 'tmdb_film_country', count(*) FROM silver.tmdb_film_country
UNION ALL SELECT 'tmdb_film_list_snapshot', count(*) FROM silver.tmdb_film_list_snapshot
UNION ALL SELECT 'cinema_idf', count(*) FROM silver.cinema_idf
UNION ALL SELECT 'crm_account', count(*) FROM silver.crm_account
UNION ALL SELECT 'crm_contact', count(*) FROM silver.crm_contact
UNION ALL SELECT 'crm_opportunity', count(*) FROM silver.crm_opportunity
UNION ALL SELECT 'crm_account_cinema_link', count(*) FROM silver.crm_account_cinema_link;

-- Statut final du run
UPDATE silver.etl_run_log
   SET finished_at = clock_timestamp(),
       status = CASE WHEN EXISTS (SELECT 1 FROM silver.dq_results
                                  WHERE run_id = :run_id AND severity = 'BLOQUANT' AND status = 'KO')
                     THEN 'FAILED' ELSE 'SUCCESS' END
 WHERE run_id = :run_id;

SELECT run_id, status, started_at, finished_at, round(extract(epoch FROM finished_at - started_at)::numeric, 2) AS duree_s
FROM silver.etl_run_log WHERE run_id = :run_id;

-- Code retour non nul si contrôle BLOQUANT KO (utile en CI / script)
\o /dev/null
SELECT silver.f_raise('Run ' || :run_id || ' : ' || count(*) || ' contrôle(s) BLOQUANT(S) en échec')
FROM silver.dq_results WHERE run_id = :run_id AND severity = 'BLOQUANT' AND status = 'KO'
HAVING count(*) > 0;
\o

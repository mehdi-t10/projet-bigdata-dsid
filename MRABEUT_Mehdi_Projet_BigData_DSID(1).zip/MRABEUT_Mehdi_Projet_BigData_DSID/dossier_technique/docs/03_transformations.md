# 3. Transformations Bronze → Silver (SQL PostgreSQL)

Toutes les transformations sont écrites en **SQL versionné** dans `sql/silver/` et orchestrées par `sql/run_all.sql`. Airbyte ne transforme rien.

| Ordre | Fichier | Rôle |
|---|---|---|
| 0 | `00_functions.sql` | casts « sûrs » (`f_to_num`, `f_to_int`, `f_to_date`, `f_to_ts`, `f_to_bool`), normalisation (`f_clean_text`, `f_norm_key(s)`, `f_norm_name`), extraction `f_payload`, tables techniques `etl_run_log`, `dq_results` |
| 1 | `01_staging_views.sql` | une vue `silver.stg_*` par table Bronze, colonnes homogènes : `bronze_table, bronze_raw_id, bronze_extracted_at, source_file, source_file_modified, payload` |
| 2 | `10_tmdb.sql` | films, genres, liaisons, historique de popularité |
| 3 | `20_cinemas.sql` | établissements CNC Île-de-France |
| 4 | `30_crm.sql` | comptes, contacts, opportunités |
| 5 | `40_conformed.sql` | rapprochements inter-flux + vue 360° |

![Modèle Silver](uml/export/07_classes_silver.svg)

## 3.1 Principes communs

| Principe | Mise en œuvre |
|---|---|
| **Idempotence** | chaque table Silver est reconstruite (`DROP` + `CREATE` + `INSERT … SELECT`) ; relancer donne le même résultat |
| **Atomicité** | les 4 scripts de construction s'exécutent dans **une seule transaction** : en cas d'erreur, l'ancien Silver reste intact |
| **Typage explicite** | DDL avec types précis (`date`, `numeric(4,2)`, `char(5)`, `boolean`…) + clés primaires |
| **Cast sûr** | une valeur non convertible devient `NULL` au lieu de faire échouer le run ; elle est **comptée** par les contrôles TYPES |
| **Dédoublonnage** | `DISTINCT ON (clé) … ORDER BY date_fichier DESC, _airbyte_extracted_at DESC, _airbyte_raw_id DESC` → dernière version, déterministe |
| **Traçabilité** | chaque ligne Silver garde `bronze_raw_id` (+ `source_file` pour les flux via MinIO) et `silver_loaded_at` |
| **Découplage Bronze** | Silver ne lit que les vues `stg_*` ; si un nom de table Bronze change, seul `01_staging_views.sql` est modifié |
| **Robustesse au format** | `to_jsonb(ligne)` + `f_payload` : fonctionne que la destination S3 soit en *No flattening* ou *Root level flattening* |

## 3.2 Flux 1 — TMDB

| Table Silver | Grain | Règles |
|---|---|---|
| `tmdb_genre` | 1 genre | id entier, libellé nettoyé, dernière version |
| `tmdb_film` | 1 film | union des 3 listes (`FULL JOIN` détails) ; dernière version par `film_id` ; titre/overview nettoyés (espaces multiples) ; `release_date` → `date` + `release_year` ; `runtime/budget/revenue = 0` → `NULL` (0 = inconnu chez TMDB) ; `popularity numeric(12,4)`, `vote_average numeric(4,2)` ; indicateurs `in_now_playing / in_popular / in_trending_week` ; `first_seen_at / last_seen_at` |
| `tmdb_film_genre` | film × genre | dépliage `genre_ids[]` (listes) ∪ `genres[].id` (détails) via `jsonb_array_elements` |
| `tmdb_film_country` | film × pays | dépliage `production_countries[]`, code ISO2 validé |
| `tmdb_film_list_snapshot` | film × liste × jour | **historisation** de la popularité/votes à chaque extraction (le RAW est en *Append*) |

## 3.3 Flux 2 — Cinémas IDF

`silver.cinema_idf` (1 ligne par établissement) :

1. normalisation des clés JSON (`f_norm_keys` : minuscules, sans accents, `_`) ;
2. sélection tolérante des colonnes (`f_pick` avec alias) ;
3. colonne « entrées » la plus récente détectée par motif `entrees_AAAA` (`f_latest_entrees`) ;
4. `code_insee` en `char(5)` (zéros conservés), `departement` = `DEP` ou 2 premiers caractères de l'INSEE ;
5. `écrans / fauteuils / séances` → entiers ; `latitude / longitude` → `numeric(9,6)` (virgule décimale acceptée) ;
6. `AE` → `is_art_et_essai` ; `multiplexe` (OUI/NON) → booléen ;
7. ligne sans nom écartée ; identifiant absent → clé de substitution `H_` + hash (signalée par `id_is_surrogate`) ;
8. dédoublonnage par `cinema_id` (dernier fichier) ; `cinema_name_norm` pour le rapprochement CRM.

## 3.4 Flux 3 — EspoCRM

1. vues `stg_crm_*_last` : **dernière version** par `id` (tri `modified_at`), *avant* le filtre des suppressions → une fiche supprimée après modification disparaît bien ;
2. exclusion de `deleted = 1` ;
3. e-mail **principal** reconstitué via `entity_email_address` (`primary = 1`) + `email_address`, mis en minuscules ; validité = regex + indicateur `invalid` d'EspoCRM ;
4. noms : prénom en *Initcap*, nom en MAJUSCULES, `full_name` ;
5. opportunités : `amount numeric(14,2)`, `probability_pct`, `weighted_amount = amount × probabilité`, `stage_fr`, `is_closed`, `is_won`, `close_date` ;
6. champs personnalisés optionnels `c_cnc_id` (compte) et `c_tmdb_id` (opportunité).

## 3.5 Rapprochements (40_conformed.sql)

- `crm_account_cinema_link` : `c_cnc_id` exact (confiance 1.0) → sinon nom normalisé + ville (0.8) → sinon nom unique en IDF (0.5) ;
- `v_opportunity_360` : opportunité + compte + contact + cinéma CNC + film TMDB.

![Lignage](uml/export/10_lignage_donnees.svg)

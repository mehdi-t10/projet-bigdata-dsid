# 6. Saisie des données dans EspoCRM (flux 3)

Le sujet impose des **nouvelles données saisies dans EspoCRM**. Connexion : http://localhost:8081 (`ESPOCRM_ADMIN_USERNAME` / `ESPOCRM_ADMIN_PASSWORD`).

## 6.1 (Optionnel, recommandé) Champs personnalisés de rapprochement

*Administration → Entity Manager* :

| Entité | Champ | Type | Libellé | Colonne MariaDB |
|---|---|---|---|---|
| Account (Compte) | `cncId` | Varchar | N° CNC (N° auto) | `c_cnc_id` |
| Opportunity | `tmdbId` | Integer | ID film TMDB | `c_tmdb_id` |

Puis *Administration → Layout Manager* pour afficher ces champs dans le formulaire. Après création, **rafraîchir le schéma** de la source MySQL dans Airbyte (*Connection → Schema → Refresh source schema*).

## 6.2 Jeu de saisie proposé (minimum conseillé)

| Entité | Nombre | Exemple |
|---|---|---|
| Comptes | 5 | cinémas réels d'IDF (nom **identique** au fichier CNC, ville de facturation renseignée, N° CNC si champ créé) |
| Contacts | 8 | rattachés à un compte, avec e-mail (dont 1 volontairement invalide pour illustrer le contrôle) |
| Opportunités | 6 | « Programmation <film à l'affiche> – <cinéma> », montant, probabilité, étape, date de clôture, ID TMDB du film |

Pour trouver l'ID TMDB d'un film à l'affiche, après la première synchro :
```sql
SELECT film_id, title FROM silver.tmdb_film WHERE in_now_playing ORDER BY popularity DESC LIMIT 20;
```
Pour trouver le N° CNC d'un cinéma :
```sql
SELECT cinema_id, cinema_name, commune FROM silver.cinema_idf WHERE commune ILIKE '%massy%';
```

## 6.3 Scénario de démonstration proposé (modifications / suppressions)

1. Saisir les données → synchro `espocrm → bronze` → `run_silver`.
2. Modifier la ville d'un contact et l'étape d'une opportunité (`Closed Won`) → synchro → `run_silver` : Bronze contient **2 versions**, Silver n'en garde qu'**une** (contrôle `doublons_bronze_crm_versions`).
3. Supprimer un contact dans EspoCRM (suppression logique `deleted = 1`) → synchro → `run_silver` : le contact disparaît de Silver.

Les captures des saisies EspoCRM figurent dans le rapport (section « Preuves d'exécution »).

> **Limite connue — suppressions.** Selon la version d'EspoCRM, une suppression (`deleted = 1`) ne met pas forcément à jour `modified_at` : la synchronisation incrémentale par curseur peut alors ne pas la détecter. Contournement : lancer un *Refresh* (rechargement complet) du stream `contact` dans Airbyte, ou passer la connexion en *Full refresh | Overwrite*. Seul le mode CDC (lecture du binlog MariaDB) capte toutes les suppressions.

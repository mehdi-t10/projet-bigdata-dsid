# 5. Reproductibilité

## 5.1 Versions figées

| Composant | Version | Où c'est figé |
|---|---|---|
| PostgreSQL | 18.6 | `compose.yaml` |
| MariaDB | 11.8.9 | `compose.yaml` |
| EspoCRM (+ daemon) | 10.0.8 | `compose.yaml` |
| MinIO | `RELEASE.2025-10-15T17-29-55Z` (build local Go 1.24 / Alpine 3.23) | `compose.yaml`, `Dockerfile.minio` |
| Adminer | 6.1.0 | `compose.yaml` |
| Airbyte | installé par `abctl` v0.30.4 | `abctl version` |
| Connecteurs Airbyte (relevés) | source-file 0.6.0, source-s3 4.15.25, source-mysql 3.53.5, destination-s3 1.9.9, destination-postgres 3.0.22, source-declarative-manifest 7.28.2 | *Settings → Sources/Destinations* |
| Connecteur TMDB | manifeste déclaratif `version: 6.33.0` | `airbyte/connectors/tmdb_manifest.yaml` |
| Client `mc` (MinIO) | `MC_IMAGE` (défaut `minio/mc:latest`) | non utilisé en pratique (console MinIO + compte root, voir rapport) |

`scripts/check_stack.sh` affiche `docker compose images`, `abctl version`, les schémas, les tables Bronze, les droits MariaDB et la passerelle kind (sorties reportées dans le rapport PDF).

## 5.2 Secrets

- `.env` n'est **jamais** versionné (`.gitignore`) ; seul `.env.example` (valeurs factices) est rendu.
- Le token TMDB n'existe que dans Airbyte (champ `airbyte_secret`, masqué).
- Comptes à moindre privilège : `airbyte` (MariaDB, `SELECT`), `airbyte_writer` (PostgreSQL, écriture sur `bronze` uniquement), utilisateur MinIO limité au bucket `dsid-raw` (`minio/policy-airbyte-raw.json`).

## 5.3 Différences selon l'OS

| Sujet | Windows | macOS | Linux |
|---|---|---|---|
| Copier l'environnement | `Copy-Item .env.example .env` | `cp .env.example .env` | `cp .env.example .env` |
| Scripts | `scripts\*.ps1` (ou Git Bash pour `.sh`) | `scripts/*.sh` | `scripts/*.sh` |
| Hôte vu depuis Airbyte | `host.docker.internal` | `host.docker.internal` | `host.docker.internal` ou IP passerelle kind |
| Fins de ligne | configurer `git config core.autocrlf input` pour que les `.sh` montés dans les conteneurs restent en LF | — | — |

## 5.4 Idempotence et rejeu

| Élément | Comportement si relancé |
|---|---|
| `init/postgres`, `init/mariadb` | exécutés au **premier** démarrage du volume ; relançables à la main (commandes en tête de fichier) |
| `scripts/setup_minio.sh` | `--ignore-existing`, policy déjà présente tolérée |
| Synchros RAW (Append) | ajoutent un nouveau fichier horodaté : historique conservé |
| Synchros Bronze S3 (Overwrite) | rechargent l'intégralité du RAW |
| `sql/run_all.sql` | reconstruit Silver à l'identique (transaction unique) ; nouveau `run_id` |

## 5.5 Repartir de zéro

```bash
docker compose stop
docker compose down -v      # ⚠ supprime TOUTES les données locales (volumes)
docker compose build minio && docker compose up -d
./scripts/setup_minio.sh
# puis relancer les synchronisations Airbyte et ./scripts/run_silver.sh
```

## 5.6 Tester sans Airbyte

`./scripts/test_offline.sh` crée une base séparée `warehouse_dev`, y charge un Bronze **fictif** et exécute tout le SQL Silver + contrôles. La base `warehouse` n'est pas modifiée. Le générateur `sql/dev/generate_fixtures.py` permet de régénérer ces données.

# 4. Contrôles qualité

Les contrôles sont du SQL (`sql/tests/`) exécuté automatiquement par `run_all.sql`. Chaque résultat est **historisé** dans `silver.dq_results` (un `run_id` par exécution, journal `silver.etl_run_log`).

- **BLOQUANT** : un KO met le run en `FAILED` et le script retourne un code ≠ 0 ;
- **AVERTISSEMENT** : signalé dans le rapport, le run reste `SUCCESS`.

![Activité](uml/export/08_activite_run_silver.svg)

## 4.1 Précontrôles sur Bronze (`00_prechecks_bronze.sql`) — avant toute transformation

| Catégorie | Contrôle | Sévérité |
|---|---|---|
| STRUCTURE | table Bronze présente (tmdb_*, csv_cinemas_idf, crm_*) | BLOQUANT (optionnelles : AVERT.) |
| STRUCTURE | colonnes Airbyte `_airbyte_raw_id`, `_airbyte_extracted_at` présentes | BLOQUANT |
| VOLUMES | table Bronze non vide | BLOQUANT |
| TRACABILITE | `_ab_source_file_url` renseigné (flux via MinIO) | AVERT. |

## 4.2 Contrôles Silver (`10_dq_silver.sql`)

| Catégorie | Contrôles | Sévérité |
|---|---|---|
| **STRUCTURE** | 35 couples colonne/type attendus (`information_schema.columns`) ; clé primaire déclarée sur chaque table | BLOQUANT |
| **TYPES** | `release_date`, `close_date` non convertibles ; `vote_average`, `amount` non numériques ; écrans/fauteuils non entiers | BLOQUANT / AVERT. |
| **UNICITE** | `film_id`, `genre_id`, `cinema_id`, `account_id`, `contact_id`, `opportunity_id` uniques ; e-mail partagé par 2 contacts | BLOQUANT / AVERT. |
| **DOUBLONS** | nombre de doublons Bronze éliminés (films, cinémas, versions CRM) ; doublons probables restants (même nom + commune, même contact + compte) | AVERT. (information) |
| **VOLUMES** | Silver non vide ; films Silver = ids distincts Bronze ; contacts/opportunités Silver = actifs Bronze ; ordres de grandeur (15–30 genres, ≥ 250 cinémas IDF) | BLOQUANT / AVERT. |
| **TRACABILITE** | tout `bronze_raw_id` Silver existe en Bronze ; `source_file` renseigné | BLOQUANT / AVERT. |
| **INTEGRITE** | contact → compte, opportunité → compte ; genre connu ; film TMDB de l'opportunité connu ; % comptes reliés à un cinéma | BLOQUANT / AVERT. |
| **DOMAINE** | `vote_average ∈ [0;10]`, votes/popularité ≥ 0, durée ∈ ]0;600], département ∈ IDF, INSEE cohérent, coordonnées dans l'emprise IDF, fauteuils ≥ écrans, montant ≥ 0, probabilité ∈ [0;100], format e-mail, contact joignable | BLOQUANT / AVERT. |
| **FRAICHEUR** | dernière extraction < 7 jours | AVERT. |

## 4.3 Lecture des résultats

```sql
-- Dernier run
SELECT * FROM silver.etl_run_log ORDER BY run_id DESC LIMIT 1;
-- Contrôles KO du dernier run
SELECT severity, category, test_name, table_name, observed, expected, details
FROM silver.dq_results
WHERE run_id = (SELECT max(run_id) FROM silver.etl_run_log) AND status = 'KO';
-- Évolution d'un contrôle dans le temps
SELECT run_id, status, observed FROM silver.dq_results
WHERE test_name = 'films_bronze_egal_silver' ORDER BY run_id;
```

## 4.4 Preuve que les contrôles détectent les anomalies

`scripts/test_offline.sh` charge un Bronze **fictif** (`sql/dev/fake_bronze.sql`) contenant des anomalies volontaires. Résultat obtenu (PostgreSQL, 109 contrôles exécutés, 0 BLOQUANT KO, 5 AVERTISSEMENTS attendus) :

| Anomalie injectée | Contrôle qui la détecte | Résultat |
|---|---|---|
| `release_date = "2026-13-45"` | TYPES `release_date_convertible` | KO (1) |
| e-mail `lucas.bernard@exemple` | DOMAINE `email_format_valide` | KO (1) |
| contact sans e-mail ni téléphone | DOMAINE `contact_joignable` | KO (1) |
| opportunité liée au film 999999 | INTEGRITE `opportunite_film_tmdb_connu` | KO (1) |
| ligne CSV ré-ingérée + ligne sans nom | DOUBLONS `doublons_bronze_cinemas_elimines` | 2 lignes écartées |
| contact en 2 versions + contact supprimé | VOLUMES `contacts_bronze_egal_silver` | OK : 4 contacts (version la plus récente, supprimé exclu) |
| `vote_average = 15` (test manuel) | DOMAINE `vote_average_0_10` (BLOQUANT) | run FAILED, code retour 3 |
| table `bronze.crm_contact` supprimée (test manuel) | STRUCTURE `bronze_table_presente` | arrêt avant transformation, run FAILED |

# 2. Documentation des flux (configuration Airbyte)

![Architecture](uml/export/01_architecture_composants.svg)

Six connexions Airbyte réalisent les trois flux :

| Flux | Connexion | Source | Destination | Mode de synchro |
|---|---|---|---|---|
| 1 | `tmdb → minio_raw` | TMDB (DSID) — connecteur Builder | S3 (MinIO) `raw/api/tmdb` | Full refresh \| Append |
| 1 | `minio_tmdb → bronze` | S3 (MinIO) — 5 streams | Postgres `bronze` | Full refresh \| Overwrite |
| 2 | `csv_cinemas → minio_raw` | File (CSV HTTPS) | S3 (MinIO) `raw/csv` | Full refresh \| Append |
| 2 | `minio_csv → bronze` | S3 (MinIO) — 1 stream | Postgres `bronze` | Full refresh \| Overwrite |
| 3 | `espocrm → bronze` | MySQL (MariaDB) | Postgres `bronze`, préfixe `crm_` | Incremental \| Append (curseur `modified_at`) |

**Logique des couches**

- **RAW (MinIO)** : copie immuable de chaque extraction API/CSV, un fichier JSONL horodaté par synchro → rejouable, auditable.
- **Bronze (PostgreSQL)** : chargement fidèle, sans transformation (seules les colonnes techniques Airbyte/S3 sont ajoutées).
- **Silver (PostgreSQL)** : SQL versionné (`sql/`), typé, dédoublonné, contrôlé — **aucune** transformation n'est faite dans Airbyte.

## 2.0 Adresse des services vus depuis Airbyte

Airbyte tourne dans un cluster *kind* séparé : `localhost` ne désigne pas la machine hôte.

| OS | Hôte à saisir dans les connecteurs |
|---|---|
| Windows / macOS | `host.docker.internal` |
| Linux | `host.docker.internal` si résolu, sinon IP de passerelle du nœud kind (`scripts/check_stack.sh`, ex. `172.18.0.1`) — valeur utilisée pour ce projet (Windows) : `host.docker.internal` |

Dans la suite : `<HOTE>` = cette valeur.

## 2.1 Connecteur TMDB (Connector Builder)

1. Airbyte → **Builder** → **Import a YAML** → `airbyte/connectors/tmdb_manifest.yaml`.
2. Onglet **Testing values** : coller le token TMDB dans *API Read Access Token* → **Test** sur chaque stream (genres, movies_now_playing, …, movie_details).
3. **Publish** (nom : `TMDB (DSID)`, version 1).
4. **Sources → New source → TMDB (DSID)** : saisir token / `fr-FR` / `FR` / `max_pages = 5` → *Test the source*.

Le manifeste a été validé avec airbyte-cdk 7.35 (check OK, 5 streams découverts, pagination arrêtée à `max_pages`, 404 ignoré, 401 → échec contrôlé) sur un serveur simulant l'API.

## 2.2 Destination S3 → MinIO (RAW)

| Champ | Valeur |
|---|---|
| S3 Key ID / Secret | `MINIO_AIRBYTE_ACCESS_KEY` / `MINIO_AIRBYTE_SECRET_KEY` (`.env`, créés par `scripts/setup_minio.sh`) |
| S3 Bucket Name | `dsid-raw` |
| S3 Bucket Path | `raw/api/tmdb` (destination n°1) — `raw/csv` (destination n°2) |
| S3 Bucket Region | `us-east-1` |
| Endpoint | `http://<HOTE>:9000` |
| Output format | **JSON Lines**, compression *No compression*, flattening **No flattening** |
| S3 Path Format | `${STREAM_NAME}/${YEAR}_${MONTH}_${DAY}_${EPOCH}_` |

Deux destinations S3 distinctes (même MinIO, préfixes différents) garantissent la séparation `raw/api/...` / `raw/csv/...` demandée. Résultat : `dsid-raw/raw/api/tmdb/movies_popular/2026_10_12_1791…_0.jsonl`.

> *No flattening* : la donnée métier est rangée dans `_airbyte_data`. Le SQL Silver gère aussi le cas *Root level flattening* (`silver.f_payload`).

## 2.3 Source File — CSV cinémas

| Champ | Valeur |
|---|---|
| Dataset name | `cinemas_idf` |
| File format | `csv` |
| Storage provider | `HTTPS: Public Web` |
| URL | `https://data.iledefrance.fr/api/explore/v2.1/catalog/datasets/salle_de_cinema_ile-de-france/exports/csv?use_labels=true` |
| Reader options | `{"sep": ";", "encoding": "utf-8"}` |

## 2.4 Source S3 (lecture MinIO) → bronze

| Champ | Valeur |
|---|---|
| Bucket | `dsid-raw` |
| Endpoint | `http://<HOTE>:9000` |
| Access key / secret | compte Airbyte MinIO |

Streams (format **Jsonl**, *validation policy : Emit record*) :

| Stream (= table bronze) | Globs |
|---|---|
| `tmdb_genres` | `raw/api/tmdb/genres/**/*.jsonl` |
| `tmdb_movies_now_playing` | `raw/api/tmdb/movies_now_playing/**/*.jsonl` |
| `tmdb_movies_popular` | `raw/api/tmdb/movies_popular/**/*.jsonl` |
| `tmdb_trending_week` | `raw/api/tmdb/trending_week/**/*.jsonl` |
| `tmdb_movie_details` | `raw/api/tmdb/movie_details/**/*.jsonl` |
| `csv_cinemas_idf` | `raw/csv/cinemas_idf/**/*.jsonl` |

Le connecteur ajoute `_ab_source_file_url` et `_ab_source_file_last_modified` : **traçabilité ligne → fichier MinIO**, réutilisée en Silver (`source_file`).

> **Collision de colonnes (problème rencontré et résolu)** : les fichiers JSONL du RAW contiennent déjà `_airbyte_raw_id`, `_airbyte_extracted_at`, `_airbyte_meta`, `_airbyte_generation_id` (écrits par la destination S3). La destination Postgres ajoute les siennes → erreur `column "_airbyte_raw_id" specified more than once`. Solution : dans la connexion `minio_raw -> bronze`, onglet *Schema*, **sélection de colonnes** : ne garder que `_airbyte_data`, `_ab_source_file_url`, `_ab_source_file_last_modified` (fait automatiquement par `scripts/airbyte_setup.py`).

> **Point HTTPS (README_DOCKER §11)** : les versions récentes du connecteur Source S3 peuvent refuser un endpoint `http://`. Résultat obtenu : avec `airbyte/source-s3:4.15.25`, l'endpoint `http://host.docker.internal:9000` est **accepté** (Test connection et synchronisation complète MinIO → PostgreSQL réussis). En cas de refus avec une autre version : *Settings → Sources → S3 → Change version* pour figer une version qui accepte l'HTTP, ou exposer MinIO en HTTPS.

## 2.5 Source MySQL — EspoCRM

| Champ | Valeur |
|---|---|
| Host / Port | `<HOTE>` / `3306` (ou `MARIADB_HOST_PORT` : `3307` sur la machine de développement) |
| Database | `espocrm` |
| Username / Password | `airbyte` / `AIRBYTE_MARIADB_PASSWORD` (droit `SELECT` uniquement) |
| SSL mode | `preferred` (local) |
| Update method | **Scan changes with user defined cursor** |

Streams sélectionnés : `account`, `contact`, `opportunity`, `email_address`, `entity_email_address` (+ `phone_number`, `entity_phone_number` optionnels). Mode **Incremental | Append**, curseur `modified_at` (tables liaison e-mail : *Full refresh | Overwrite*, sans `modified_at`).

> Avec *Append*, chaque modification ajoute une nouvelle version dans Bronze (historique conservé) ; Silver ne retient que la **dernière version** par `id` et exclut `deleted = 1`.

## 2.6 Destination Postgres → bronze

| Champ | Valeur |
|---|---|
| Host / Port | `<HOTE>` / `5432` (ou `POSTGRES_HOST_PORT` : `5433` sur la machine de développement) |
| DB Name | `warehouse` |
| Default Schema | `bronze` |
| User / Password | `airbyte_writer` / `AIRBYTE_PG_PASSWORD` (droits limités à `bronze`) |
| SSL | `disable` (local) |

Dans chaque connexion : *Destination Namespace* = **Destination-defined** (→ `bronze`) ; préfixe de stream `crm_` pour la connexion EspoCRM uniquement.

## 2.7 Ordre d'exécution

1. `tmdb → minio_raw` et `csv_cinemas → minio_raw` (RAW) ;
2. `minio_tmdb → bronze`, `minio_csv → bronze`, `espocrm → bronze` ;
3. `scripts/run_silver.sh` (Silver + contrôles).

Diagrammes de séquence : [flux 1](uml/export/03_sequence_flux1_api.svg), [flux 2](uml/export/04_sequence_flux2_csv.svg), [flux 3](uml/export/05_sequence_flux3_crm.svg).

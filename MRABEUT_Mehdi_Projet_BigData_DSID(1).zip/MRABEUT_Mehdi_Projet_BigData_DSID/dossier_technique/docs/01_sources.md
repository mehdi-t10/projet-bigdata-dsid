# 1. Documentation des sources

Fil conducteur du projet : un **distributeur de films** suit ses clients exploitants de salles (CRM), les films qu'il programme (API TMDB) et le parc de cinémas d'Île-de-France (open data CNC).

| # | Source | Type | Accès | Authentification | Fréquence de mise à jour | Licence |
|---|--------|------|-------|------------------|--------------------------|---------|
| 1 | **TMDB — The Movie Database** | API REST JSON | api.themoviedb.org/3 (GET) | **Bearer token** (API Read Access Token v4) | quotidienne (films à l'affiche, popularité) | Conditions TMDB (non commercial) |
| 2 | **Cinémas actifs en Île-de-France** (CNC / Région IDF) | Fichier CSV (`;`) | export CSV data.iledefrance.fr (URL complète : docs/02 §2.3) | aucune (public) | annuelle | Licence Ouverte Etalab |
| 3 | **EspoCRM 10.0.8** (base MariaDB `espocrm`) | Base relationnelle | MariaDB `:3306` | compte `airbyte` en **lecture seule** | à chaque saisie | données internes (fictives, saisies pour le projet) |

## 1.1 API TMDB (flux 1)

### Contrat de données de l'API TMDB

| # | Question | Réponse |
|-|----|--------------------|
| 1 | **Objet métier / domaine du flux** | Le **catalogue de films** exploité par un distributeur : films actuellement à l'affiche en France, films populaires, tendances de la semaine, leurs genres et leurs fiches détaillées (durée, budget, pays…). |
| 2 | **URL GET appelées** | Base `https://api.themoviedb.org/3/` · `GET /genre/movie/list?language=fr-FR` · `GET /movie/now_playing?language=fr-FR&region=FR&page={n}` · `GET /movie/popular?language=fr-FR&region=FR&page={n}` · `GET /trending/movie/week?language=fr-FR&page={n}` · `GET /movie/{movie_id}?language=fr-FR` (une fois par film à l'affiche). En-tête `Authorization: Bearer <token>`. |
| 3 | **Grain d'un enregistrement** | Listes : **1 film × 1 liste × 1 extraction** · `genres` : 1 genre · `movie_details` : 1 film (fiche complète). En Silver : 1 film (`tmdb_film`), 1 film × liste × jour (`tmdb_film_list_snapshot`). |
| 4 | **Clé d'identification** | `id` (identifiant TMDB du film, entier) ; `id` du genre pour `genres`. Clés Silver : `film_id`, `genre_id`, (`film_id`, `genre_id`), (`film_id`, `list_type`, `snapshot_date`). `imdb_id` conservé comme identifiant secondaire. |
| 5 | **Pagination / complétude** | Pagination par paramètre `page` ; chaque réponse contient `page`, `total_pages`, `total_results` et 20 films dans `results[]`. L'extraction s'arrête quand `page = total_pages` **ou** quand `page = max_pages` (input du connecteur, 5 → 100 films max par liste, borne volontaire). Complétude vérifiée par les volumes : 4 × 100 films et 19 genres chargés ; contrôle Silver « films Silver = ids distincts Bronze ». |
| 6 | **Types des champs** | **Identifiants** : `id`, `genre_ids[]`, `imdb_id` · **Dates** : `release_date` (AAAA-MM-JJ) · **Nombres** : `popularity`, `vote_average` (décimaux), `vote_count`, `runtime`, `budget`, `revenue` (entiers) · **Booléens** : `adult`, `video` · **Textes** : `title`, `original_title`, `overview`, `original_language`, `status`, `tagline` · **Tableaux d'objets** : `genres`, `production_countries`, `spoken_languages`. |
| 7 | **Fréquence / fraîcheur** | **Quotidienne** : la popularité évolue chaque jour et les sorties en salle changent chaque semaine (mercredi en France). Synchronisation manuelle pendant le projet ; planification quotidienne recommandée. Contrôle de fraîcheur Silver : dernière extraction de moins de 7 jours. |
| 8 | **Limites et conditions** | Authentification obligatoire (*API Read Access Token*, compte TMDB gratuit). Débit : TMDB indique une limite « de l'ordre de 40 requêtes par seconde », susceptible d'évoluer, et demande de respecter les réponses **HTTP 429** → le connecteur réessaie avec une attente exponentielle. Usage **non commercial**, avec attribution à TMDB. Un film peut disparaître (**404** ignoré sur les détails) ; les contenus dépendent de la langue et de la région demandées. |

### Détails techniques du connecteur


**Pourquoi cette API ?** Elle impose une authentification par token (exigence de l'enseignant), offre plusieurs endpoints exploitables en **plusieurs streams**, une pagination, et un endpoint de détail permettant un **sous-stream** (parent → enfant).

**Obtenir le token** : créer un compte sur themoviedb.org → *Paramètres* → *API* → demander une clé (usage « Developer / Educational ») → copier **« API Read Access Token »** (long jeton commençant par `eyJ…`). Ce jeton est saisi **uniquement** dans le formulaire Airbyte (champ masqué `airbyte_secret`) : il n'apparaît ni dans Git, ni dans `.env`, ni dans les logs.

| Stream Airbyte | Endpoint GET | Clé primaire | Pagination | Volume indicatif |
|---|---|---|---|---|
| `genres` | `/genre/movie/list?language=fr-FR` | `id` | non | ~19 lignes |
| `movies_now_playing` | `/movie/now_playing?region=FR&language=fr-FR&page=n` | `id` | `page` / `total_pages` (≤ `max_pages`) | ≤ 20 × max_pages |
| `movies_popular` | `/movie/popular?region=FR&page=n` | `id` | idem | ≤ 20 × max_pages |
| `trending_week` | `/trending/movie/week?page=n` | `id` | idem | ≤ 20 × max_pages |
| `movie_details` | `/movie/{id}` pour chaque film de `movies_now_playing` | `id` | sous-stream | 1 appel par film à l'affiche |

**Paramètres (inputs) du connecteur** : `api_token` (obligatoire, secret), `language` (défaut `fr-FR`), `region` (défaut `FR`), `max_pages` (défaut 5, borne 1–50, limite le volume et le nombre d'appels).

**Gestion d'erreurs** : 429 / 5xx → nouvelle tentative avec attente exponentielle (5 essais) ; 401 → échec explicite « token invalide » ; 404 sur un détail de film → ligne ignorée.

**Champs ajoutés par le connecteur (traçabilité)** : `_list_type` (liste d'origine), `_src_language`, `_src_region`.

## 1.2 CSV cinémas Île-de-France (flux 2)

Une ligne = un établissement actif (315 établissements lors de l'extraction). En-têtes réels (libellés, avec accents) : `ID`, `Nom de l'établissement`, `Adresse`, `Adresse postale complète`, `Code postal`, `Code Insee`, `Commune`, `Écrans`, `Fauteuils`, `Art et essai` (OUI/NON), `Multiplexe` (OUI/NON), `3D`, `Genre`, `Géo` (« lat, lon »).

Points d'attention identifiés (traités en Silver) :

- en-têtes avec accents, espaces et apostrophes (`Nom de l'établissement`, `Écrans`) → normalisation des clés (`nom_de_l_etablissement`, `ecrans`) ;
- valeurs numériques (`Écrans`, `Fauteuils`, `Code Insee`) → typage explicite, code INSEE conservé en **texte sur 5 caractères** ;
- coordonnées regroupées dans `Géo` (« lat, lon ») → séparées en `latitude` / `longitude` ;
- indicateurs `OUI` / `NON` (`Art et essai`, `Multiplexe`) → booléens ;
- ré-ingestion du même fichier → doublons dans Bronze → dédoublonnage par `ID`.

## 1.3 EspoCRM / MariaDB (flux 3)

Données **saisies à la main** dans l'interface EspoCRM (http://localhost:8081) : voir [06_saisie_crm.md](06_saisie_crm.md).

| Table MariaDB | Contenu | Colonnes utiles |
|---|---|---|
| `account` | comptes (cinémas clients, partenaires) | `id`, `name`, `type`, `industry`, `website`, `billing_address_*`, `c_cnc_id`*, `deleted`, `created_at`, `modified_at` |
| `contact` | contacts | `id`, `first_name`, `last_name`, `salutation_name`, `account_id`, `address_*`, `deleted`, `modified_at` |
| `opportunity` | opportunités (programmation d'un film) | `id`, `name`, `stage`, `amount`, `amount_currency`, `probability`, `close_date`, `account_id`, `contact_id`, `c_tmdb_id`*, `deleted`, `modified_at` |
| `email_address` / `entity_email_address` | e-mails (stockés à part dans EspoCRM) | `name`, `invalid`, `opt_out` / `entity_id`, `entity_type`, `primary` |
| `phone_number` / `entity_phone_number` | téléphones (optionnel) | idem |

\* champs personnalisés optionnels créés dans *Administration → Entity Manager* (EspoCRM préfixe la colonne par `c_`). Ils permettent un rapprochement **exact** avec les deux autres flux ; sans eux, le rapprochement compte ↔ cinéma se fait par nom + ville.

Particularités EspoCRM gérées en Silver : **suppression logique** (`deleted = 1`), identifiants texte (17 caractères), e-mails dans des tables de liaison, étapes en anglais (`Closed Won`…).
